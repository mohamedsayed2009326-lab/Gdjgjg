import React, { useState, useMemo, useRef, useCallback, useEffect } from "react";
import * as XLSX from "xlsx";
import {
  LayoutDashboard, UploadCloud, Database, ShieldCheck,
  Search, Trash2, Pencil, X, CheckCircle2, AlertTriangle, FileDown,
  RotateCcw, ChevronLeft, ChevronRight, Car, MapPin, CalendarDays, Building2, ClipboardPaste, HardDrive, Wifi, WifiOff,
  Copy, Plus, Save, FolderOpen, TriangleAlert, Layers, Siren, Loader2
} from "lucide-react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell
} from "recharts";

/* ============================== ثوابت التصميم ============================== */
const FONT_HEAD = "'Cairo', sans-serif";
const FONT_BODY = "'IBM Plex Sans Arabic', 'Cairo', sans-serif";
const COLORS = {
  bg: "#EEF1F5", panel: "#FFFFFF", ink: "#1B2436", inkMuted: "#5B6B82",
  navy: "#122140", navyDeep: "#0B1730", gold: "#C99A3B", goldSoft: "#F3E4C0",
  good: "#2F8F5B", bad: "#C1443C", line: "#E1E5EC"
};
const CHART_COLORS = ["#122140", "#C99A3B", "#2F8F5B", "#6B7CA0", "#C1443C", "#8B6D2C"];


function getMapUrl(rawLocation) {
  const value = String(rawLocation ?? "").trim();
  if (!value) return "";
  // Preserve supplied map links exactly; add a scheme only for recognizable bare URLs.
  if (/^https?:\/\//i.test(value)) return value;
  if (/^(maps\.app\.goo\.gl|goo\.gl\/maps|www\.google\.[^/]+\/maps|google\.[^/]+\/maps)/i.test(value)) return `https://${value}`;
  // Convert Arabic-Indic digits before detecting coordinates.
  const normalized = value.replace(/[٠-٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d)).replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d));
  // Exact latitude,longitude coordinates (decimal or integer coordinates).
  const coords = normalized.match(/(-?\d{1,3}(?:\.\d+)?)\s*[,،; ]\s*(-?\d{1,3}(?:\.\d+)?)/);
  if (coords && Math.abs(Number(coords[1])) <= 90 && Math.abs(Number(coords[2])) <= 180) {
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${coords[1]},${coords[2]}`)}`;
  }
  return "";
}

function LocationCell({ value }) {
  const label = String(value ?? "").trim();
  if (!label) return "—";
  // A location name without a URL/coordinates should still be clickable: search the exact name.
  const url = getMapUrl(label) || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(label)}`;
  return <a href={url} target="_blank" rel="noopener noreferrer" style={{ color: "#1769AA", textDecoration: "underline", fontWeight: 700 }} title="فتح الموقع على خرائط Google">
    {label} <span aria-hidden="true">📍</span>
  </a>;
}

/* ============================== أدوات التطبيع العربي ============================== */
const EASTERN_DIGITS = { "٠":"0","١":"1","٢":"2","٣":"3","٤":"4","٥":"5","٦":"6","٧":"7","٨":"8","٩":"9" };

function normalizePlate(raw) {
  if (raw === null || raw === undefined) return "";
  let s = String(raw).trim();
  s = s.replace(/[٠-٩]/g, (d) => EASTERN_DIGITS[d] ?? d);
  s = s.replace(/[أإآ]/g, "ا");
  s = s.replace(/ة/g, "ه");
  s = s.replace(/ى/g, "ي");
  s = s.replace(/[ؤئ]/g, "ء");
  s = s.replace(/[\s\-\_\.\،\,\/]/g, "");
  return s.toUpperCase();
}

function getObservations(rec) {
  if (!rec) return [];
  return Array.isArray(rec.observations) ? rec.observations : [];
}

function getLatestObservation(rec) {
  if (!rec) return { date: rec?.last_date || "", street: rec?.street || "", car_type: rec?.car_type || "", order: -1 };
  const obs = getObservations(rec);
  if (!obs.length) return { date: rec?.last_date || "", street: rec?.street || "", car_type: rec?.car_type || "", order: -1 };
  return obs.reduce((latest, o) => {
    if (!latest) return o;
    return (o.order ?? -1) > (latest.order ?? -1) ? o : latest;
  }, null);
}

function getLastOccurrenceIndex(rec) {
  const obs = getObservations(rec);
  if (!obs.length) return -1;
  return obs.reduce((max, o, i) => Math.max(max, o.order ?? i), -1);
}

function getContextAroundLastOccurrence(records, rec, count = 4) {
  // السياق يُبنى حول آخر ظهور فعلي للوحة حسب ترتيب الإدخال العالمي.
  // مهم: لا نُدخل أي ظهور قديم لنفس اللوحة ضمن الـ4 قبل/بعد؛ المطلوب 4 لوحات
  // أخرى حول آخر ظهور فقط، وليس تكرار اللوحة نفسها من السجلات القديمة.
  const all = Object.values(records).flatMap(r => getObservations(r).map((o, i) => ({
    plate: r.plate_raw, normalized_plate: r.normalized_plate, ...o,
    order: Number.isFinite(Number(o.order)) ? Number(o.order) : i,
  }))).sort((a,b) => (a.order - b.order) || String(a.normalized_plate).localeCompare(String(b.normalized_plate)));

  const targetPlate = rec.normalized_plate;
  const lastOrder = getLastOccurrenceIndex(rec);
  if (lastOrder < 0) return { before: [], after: [] };

  // نحدد آخر ظهور نفسه، ثم نستبعد كل ظهورات اللوحة المطلوبة من السياق.
  const pos = all.findIndex(x => x.normalized_plate === targetPlate && x.order === lastOrder);
  if (pos < 0) return { before: [], after: [] };

  const before = [];
  for (let i = pos - 1; i >= 0 && before.length < count; i--) {
    if (all[i].normalized_plate !== targetPlate) before.push(all[i]);
  }

  const after = [];
  for (let i = pos + 1; i < all.length && after.length < count; i++) {
    if (all[i].normalized_plate !== targetPlate) after.push(all[i]);
  }

  return { before, after };
}

const COLUMN_KEYWORDS = {
  plate: ["لوحة", "لوحه", "رقم اللوحة", "رقم السيارة", "plate", "plate no", "plate number"],
  date: ["تاريخ", "التاريخ", "يوم", "date"],
  street: ["شارع", "الشارع", "موقع", "الموقع", "الحي", "اسم الحي", "احداثيات", "إحداثيات", "رابط الموقع", "رابط", "عنوان", "منطقة", "street", "location", "address", "coordinates", "map link"],
  type: ["نوع المركبة", "النوع الأساسي", "نوع السيارة", "فئة المركبة", "تصنيف المركبة", "نوع", "النوع", "موديل", "الموديل", "السيارة", "vehicle type", "vehicle", "model", "type"],
  company: ["شركة", "الشركه", "الشركة", "company", "fleet", "جهة", "ممول", "ممولة", "تمويل"],
};

function detectColumns(headerRow) {
  const result = { plate: -1, date: -1, street: -1, type: -1, company: -1 };
  headerRow.forEach((raw, i) => {
    const h = String(raw || "").trim().toLowerCase();
    if (!h) return;
    for (const key of Object.keys(COLUMN_KEYWORDS)) {
      if (result[key] === -1 && COLUMN_KEYWORDS[key].some((k) => h.includes(k.toLowerCase()))) result[key] = i;
    }
  });
  return result;
}

/* ============================== التعرف الذكي على ملف المطابقة ============================== */
const VEHICLE_TYPES = ["ونيت", "نقل", "ميكروباص", "اتوبيس", "أتوبيس", "باص", "سيارة", "مركبة", "خصوصي", "دينا", "سطحة"];
const VEHICLE_MODELS = [
  "النترا", "إلنترا", "هيلوكس", "هايلوكس", "كورولا", "كامري", "يارس", "أكسنت", "اكسنت", "سوناتا", "ازيرا", "أزيرا",
  "توسان", "سانتافي", "سبورتاج", "سيراتو", "كادنزا", "ريو", "راف فور", "راف4", "فورتشنر", "لاندكروزر", "لاند كروزر",
  "برادو", "هايلاندر", "افالون", "أفالون", "شاص", "ددسن", "باترول", "نافارا", "تيرانو", "اكس تريل", "إكس تريل",
  "سنتافي", "يوكن", "تاهو", "اكسبلورر", "إكسبلورر", "اكسبيديشن", "إكسبيديشن", "فورد", "كابرس", "ماليبو", "امبالا",
  "كريتا", "اكسنت", "سيراتو", "كوليوس", "اوبتيما", "أوبتيما", "فان", "فانكو", "هايس", "كارنفال", "ترانزيت", "دينا"
];
const COMPANY_NAMES = ["عبداللطيف جميل", "عبد اللطيف جميل", "الراجحي", "الأهلي", "البنك الأهلي", "الاهلي", "ساب", "بنك الرياض", "الإنماء", "الجزيرة", "اليسر", "ملاذ", "التوكيلات", "العربية للتمويل", "دار التمليك", "شركة الراجحي", "شركة الأهلي"];
const VIN_RE = /^[A-HJ-NPR-Z0-9]{17}$/i;
const PLATE_RE = /^(?:[A-Z]{1,4}\d{3,4}|[\u0621-\u064A]{1,4}\d{3,4})$/i;

function compactArabic(s) {
  return normalizePlate(s).replace(/[إأآ]/g, "ا").replace(/ى/g, "ي");
}
function isVIN(value) {
  const s = String(value ?? "").trim().replace(/[\s-]/g, "");
  return VIN_RE.test(s);
}
function looksLikePlate(value) {
  const s = normalizePlate(value);
  return PLATE_RE.test(s) || /^(?=.*[\u0621-\u064A])[\u0621-\u064A0-9]{5,8}$/.test(s) || /^(?=.*[A-Z])[A-Z0-9]{6,8}$/.test(s);
}
function valueHasType(value) {
  const s = compactArabic(value);
  return VEHICLE_TYPES.some(t => compactArabic(t) === s || s.includes(compactArabic(t)));
}
function valueHasVehicleModel(value) {
  const s = compactArabic(value);
  if (!s || s.length > 40 || isVIN(s) || looksLikePlate(s)) return false;
  return VEHICLE_MODELS.some(m => s === compactArabic(m) || s.includes(compactArabic(m)));
}
function valueHasCompany(value) {
  const s = compactArabic(value);
  return COMPANY_NAMES.some(c => s.includes(compactArabic(c)));
}
function looksLikeModelText(value) {
  const raw = String(value ?? "").trim();
  if (!raw || raw.length > 35 || /\d{6,}/.test(raw) || isVIN(raw) || looksLikePlate(raw)) return false;
  if (valueHasCompany(raw) || /حي |شارع|طريق|منطقة|الرياض|جدة|الدمام|مكة|المدينة/.test(raw)) return false;
  return /[A-Za-z\u0600-\u06FF]/.test(raw) && !/^\d+$/.test(raw);
}
function smartDetectMatchColumns(headers, rows) {
  const base = detectColumns(headers);
  const result = { plate: base.plate, vin: -1, type: base.type, company: base.company, date: base.date, street: base.street, note: -1 };
  const scores = Object.fromEntries(["plate","vin","type","company","date","street","note"].map(k => [k, []]));
  const sample = rows.slice(0, Math.min(rows.length, 500));

  headers.forEach((raw, i) => {
    const h = String(raw ?? "").trim().toLowerCase();
    const vals = sample.map(r => r[i]).filter(v => String(v ?? "").trim() !== "");
    let plateScore=0, vinScore=0, typeScore=0, companyScore=0, dateScore=0, streetScore=0, noteScore=0;
    if (/(لوح|plate|رقم.*سيار|رقم.*لوح)/i.test(h)) plateScore += 120;
    if (/(شاص|شاسيه|vin|chassis|هيكل|رقم.*هيكل)/i.test(h)) vinScore += 120;
    if (/(نوع|موديل|model|vehicle|type|السيارة)/i.test(h)) typeScore += 120;
    if (/(شركة|الشركه|الشركة|company|جهة|تمويل|مموله|ممولة|ممول)/i.test(h)) companyScore += 120;
    if (/(تاريخ|date|time)/i.test(h)) dateScore += 120;
    if (/(شارع|موقع|الموقع|عنوان|منطقة|location|street|address)/i.test(h)) streetScore += 120;
    if (/(ملاحظة|ملاحظات|سبب|note|reason|comment)/i.test(h)) noteScore += 120;

    let vinHits=0, plateHits=0, typeHits=0, modelHits=0, companyHits=0;
    vals.forEach(v => {
      if (isVIN(v)) vinHits++;
      if (looksLikePlate(v)) plateHits++;
      if (valueHasType(v) || valueHasVehicleModel(v)) typeHits++;
      if (valueHasVehicleModel(v)) modelHits++;
      if (valueHasCompany(v)) companyHits++;
    });
    const n = Math.max(vals.length, 1);
    vinScore += Math.round(vinHits/n*100);
    plateScore += Math.round(plateHits/n*100);
    typeScore += Math.round((typeHits/n)*90) + Math.round((modelHits/n)*80);
    companyScore += Math.round(companyHits/n*100);
    if (vals.some(v => normalizeDateValue(v) !== String(v).trim() || /^\d{1,4}[\/\-]\d{1,2}[\/\-]\d{1,4}$/.test(String(v).trim()))) dateScore += 40;
    if (vals.some(v => /حي |شارع|طريق|منطقة/.test(String(v)))) streetScore += 40;
    // عمود الموديل غالباً نص قصير متكرر مثل: النترا، هيلوكس، كورولا، حتى لو لم يوجد عنوان للعمود.
    if (vals.length) {
      const genericModelHits = vals.filter(v => looksLikeModelText(v)).length;
      typeScore += Math.round(genericModelHits/n*35);
    }
    scores.plate.push([plateScore,i]); scores.vin.push([vinScore,i]); scores.type.push([typeScore,i]);
    scores.company.push([companyScore,i]); scores.date.push([dateScore,i]); scores.street.push([streetScore,i]); scores.note.push([noteScore,i]);
  });
  for (const key of Object.keys(scores)) {
    scores[key].sort((a,b)=>b[0]-a[0]);
    if (result[key] === -1 && scores[key][0]?.[0] > 20) result[key] = scores[key][0][1];
  }
  // اللوحة وVIN حقول منفصلة، وباقي الحقول لا تتشارك العمود نفسه إلا عند عدم وجود بديل.
  const keys=["plate","vin","type","company","date","street","note"];
  for (const key of keys) {
    if (result[key] < 0) continue;
    for (const other of keys) {
      if (other===key || result[other]!==result[key]) continue;
      const a=scores[key].find(x=>x[1]===result[key])?.[0]||0;
      const b=scores[other].find(x=>x[1]===result[other])?.[0]||0;
      if (a>=b) result[other]=-1; else result[key]=-1;
    }
  }
  return result;
}
function classifyValue(value) {
  const raw=String(value??"").trim();
  if(!raw) return "";
  if(isVIN(raw)) return "رقم شاص (VIN)";
  if(looksLikePlate(raw)) return "لوحة";
  if(valueHasCompany(raw)) return "شركة";
  if(valueHasType(raw) || valueHasVehicleModel(raw)) return "نوع/موديل مركبة";
  return "بيانات إضافية";
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function parseSpreadsheet(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const wb = XLSX.read(data, { type: "array", cellDates: true });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "", raw: true });
        resolve(rows.filter((r) => r.some((c) => String(c).trim() !== "")));
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error("تعذّرت قراءة الملف"));
    reader.readAsArrayBuffer(file);
  });
}

// يحوّل قيمة تاريخ من الملف (كائن تاريخ، رقم تسلسلي إكسل، أو نص بصيغ مختلفة)
// إلى صيغة ISO موحّدة (YYYY-MM-DD) دون تغيير اليوم/الشهر/السنة الفعليين —
// أي يحافظ على تاريخ الملف كما هو، فقط بصيغة قابلة للفرز والمقارنة.
function normalizeDateValue(cell) {
  if (cell === null || cell === undefined || cell === "") return "";
  if (cell instanceof Date && !isNaN(cell)) {
    const y = cell.getFullYear();
    const m = String(cell.getMonth() + 1).padStart(2, "0");
    const d = String(cell.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  if (typeof cell === "number") {
    try {
      const parsed = XLSX.SSF.parse_date_code(cell);
      if (parsed) return `${parsed.y}-${String(parsed.m).padStart(2, "0")}-${String(parsed.d).padStart(2, "0")}`;
    } catch (e) { /* تجاهل وأكمل بالنص */ }
    return String(cell);
  }
  const s = String(cell).trim();
  if (!s) return "";
  let m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/); // dd/mm/yyyy أو dd-mm-yyyy
  if (m) return `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
  m = s.match(/^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})$/); // yyyy-mm-dd بالفعل
  if (m) return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
  return s; // صيغة غير معروفة: يُحتفظ بها كما هي دون تغيير
}

function downloadBlob(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function exportRecordsToExcel(records, filename, extraSheets = []) {
  const wb = XLSX.utils.book_new();
  const mainRows = records.map((r) => ({
    "اللوحة": r.plate_raw,
    "اللوحة الموحّدة": r.normalized_plate,
    "الشارع/الموقع": r.street,
    "نوع المركبة": r.car_type,
    "تاريخ أول رصد": r.first_date,
    "تاريخ آخر رصد": r.last_date,
    "عدد مرات الرصد": r.observations.length,
  }));
  const ws1 = XLSX.utils.json_to_sheet(mainRows);
  ws1["!cols"] = [{ wch: 16 }, { wch: 16 }, { wch: 22 }, { wch: 16 }, { wch: 14 }, { wch: 14 }, { wch: 14 }];
  XLSX.utils.book_append_sheet(wb, ws1, "قاعدة البيانات");
  extraSheets.forEach(({ name, rows }) => {
    if (!rows.length) return;
    const ws = XLSX.utils.json_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, name);
  });
  XLSX.writeFile(wb, filename);
}

/* ============================== سجل عملية جديد ============================== */
function logEntry(action, details, count) {
  return { time: new Date().toLocaleString("ar-EG"), action, details, count };
}

/* ============================== التخزين الدائم — IndexedDB V9 ============================== */
/*
 V9: التخزين مصمم بحيث لا يتم أبداً حذف الجيل النشط أثناء استيراد ملف جديد.
 - قاعدة V9 هي مصدر الحقيقة.
 - كل ملف أساسي جديد يُكتب في generation مستقل ثم يُعتمد فقط بعد اكتماله.
 - لا يوجد تنظيف تلقائي للنسخ القديمة؛ هذا يمنع فقدان البيانات بسبب Refresh/إغلاق التطبيق.
 - الإضافة العادية تكتب السجلات المتغيرة فقط.
 - اتصال IndexedDB واحد يُعاد استخدامه لتقليل البطء الناتج عن فتح/غلق القاعدة آلاف المرات.
 - عند أول تشغيل، نحاول ترحيل قاعدة V8 الحالية دون الاعتماد على حالة React.
*/
const IDB_NAME = "plates-manager-db-v9";
const IDB_VERSION = 2;
const META_STORE = "meta";
const RECORD_STORE = "records";
const LOG_STORE = "logs";
let dbPromise = null;
let persistQueue = Promise.resolve();

function makeGeneration() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
}

function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    if (!window.indexedDB) return reject(new Error("IndexedDB غير متاح في هذا المتصفح"));
    const req = indexedDB.open(IDB_NAME, IDB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(META_STORE)) db.createObjectStore(META_STORE);
      let recordStore;
      if (!db.objectStoreNames.contains(RECORD_STORE)) {
        recordStore = db.createObjectStore(RECORD_STORE, { keyPath: "key" });
      } else {
        recordStore = req.transaction.objectStore(RECORD_STORE);
      }
      // فهارس داخل IndexedDB تساعد عمليات البحث المستقبلية بدون مسح كل السجلات.
      // الحقول مخزنة داخل record لأن كل صف يحمل مفتاح الجيل الحالي.
      if (!recordStore.indexNames.contains("by_record_id")) {
        recordStore.createIndex("by_record_id", "record.id", { unique: false });
      }
      if (!recordStore.indexNames.contains("by_normalized_plate")) {
        recordStore.createIndex("by_normalized_plate", "record.normalized_plate", { unique: false });
      }
      if (!recordStore.indexNames.contains("by_plate_raw")) {
        recordStore.createIndex("by_plate_raw", "record.plate_raw", { unique: false });
      }
      if (!db.objectStoreNames.contains(LOG_STORE)) db.createObjectStore(LOG_STORE);
    };
    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => { try { db.close(); } catch {} dbPromise = null; };
      resolve(db);
    };
    req.onerror = () => { dbPromise = null; reject(req.error || new Error("فشل فتح قاعدة التخزين")); };
  });
  return dbPromise;
}

function txRequest(storeName, mode, action) {
  return openDB().then(db => new Promise((resolve, reject) => {
    let result;
    let tx;
    try {
      tx = db.transaction(storeName, mode);
      const store = tx.objectStore(storeName);
      result = action(store, tx);
    } catch (e) { reject(e); return; }
    tx.oncomplete = () => resolve(result);
    tx.onerror = () => reject(tx.error || new Error("فشلت عملية التخزين"));
    tx.onabort = () => reject(tx.error || new Error("أُلغيت عملية التخزين"));
  }));
}

async function idbGet(storeName, key) {
  return txRequest(storeName, "readonly", store => new Promise((resolve, reject) => {
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  }));
}

async function idbGetAll(storeName) {
  return txRequest(storeName, "readonly", store => new Promise((resolve, reject) => {
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  }));
}

async function idbGetRange(storeName, range) {
  return txRequest(storeName, "readonly", store => new Promise((resolve, reject) => {
    const req = store.getAll(range);
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  }));
}

async function idbGetAllKeys(storeName) {
  return txRequest(storeName, "readonly", store => new Promise((resolve, reject) => {
    const req = store.getAllKeys();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  }));
}

async function idbPut(storeName, value, key) {
  return txRequest(storeName, "readwrite", store => {
    key === undefined ? store.put(value) : store.put(value, key);
    return true;
  });
}

async function idbPutBatch(storeName, values) {
  if (!values.length) return true;
  return txRequest(storeName, "readwrite", store => {
    for (const v of values) store.put(v);
    return true;
  });
}

async function idbDelete(storeName, key) {
  return txRequest(storeName, "readwrite", store => { store.delete(key); return true; });
}

/* ============================== تنظيف الأجيال القديمة في الخلفية ==============================
   الجيل النشط لا يُحذف أبداً هنا. الهدف فقط منع تراكم أجيال قديمة ميتة (من كل عملية رفع/استعادة
   سابقة) داخل RECORD_STORE، لأن تراكمها هو السبب الرئيسي لبطء فتح التطبيق مع مرور الوقت — القراءة
   الأولى كانت تفحص كل السجلات القديمة قبل الفلترة. هذه الدالة تعمل في الخلفية على دفعات صغيرة حتى
   لا تُجمّد الواجهة، ولا تُستدعى إلا بعد أن يصبح الجيل الجديد معتمَداً ومحفوظاً بنجاح. */
let pruneRunning = false;
async function pruneStaleGenerations(activeGeneration) {
  if (pruneRunning || !activeGeneration) return;
  pruneRunning = true;
  try {
    const keys = await idbGetAllKeys(RECORD_STORE);
    const prefix = `${activeGeneration}|`;
    const staleKeys = keys.filter(k => typeof k === "string" && !k.startsWith(prefix));
    for (let i = 0; i < staleKeys.length; i += 2000) {
      const chunk = staleKeys.slice(i, i + 2000);
      await txRequest(RECORD_STORE, "readwrite", store => { chunk.forEach(k => store.delete(k)); return true; });
      await new Promise(r => setTimeout(r, 0)); // يسمح للمتصفح يتنفّس بين الدفعات على الهاتف
    }
  } catch (e) {
    console.warn("pruneStaleGenerations failed", e);
  } finally {
    pruneRunning = false;
  }
}

async function readOldV8() {
  try {
    const old = await new Promise((resolve, reject) => {
      const req = indexedDB.open("plates-manager-db-v7", 1);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    if (!old.objectStoreNames.contains("meta") || !old.objectStoreNames.contains("records")) { old.close(); return null; }
    const data = await new Promise((resolve, reject) => {
      const tx = old.transaction(["meta", "records"], "readonly");
      const m = tx.objectStore("meta").get("database");
      const r = tx.objectStore("records").getAll();
      tx.oncomplete = () => resolve({ meta: m.result || null, rows: r.result || [] });
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error("فشل قراءة قاعدة V8"));
    });
    old.close();
    return data;
  } catch { return null; }
}

async function migrateOldDatabase() {
  const old = await readOldV8();
  if (!old?.rows?.length) return null;
  let active = String(old.meta?.activeGeneration || "");
  let rows = active ? old.rows.filter(x => String(x?.key || "").startsWith(`${active}|`)) : [];
  if (!rows.length) {
    const counts = new Map();
    for (const x of old.rows) {
      const k = String(x?.key || "");
      const i = k.indexOf("|");
      if (i > 0) counts.set(k.slice(0, i), (counts.get(k.slice(0, i)) || 0) + 1);
    }
    let best = "", bestCount = 0;
    for (const [g,c] of counts) if (c > bestCount) { best = g; bestCount = c; }
    active = best;
    rows = active ? old.rows.filter(x => String(x?.key || "").startsWith(`${active}|`)) : [];
  }
  if (!rows.length) return null;
  const generation = makeGeneration();
  const values = rows.map(x => ({ key: `${generation}|${x.record?.id || String(x.key).split("|").slice(1).join("|")}`, record: x.record || x }));
  for (let i=0;i<values.length;i+=3000) await idbPutBatch(RECORD_STORE, values.slice(i,i+3000));
  const meta = { ...(old.meta || {}), activeGeneration: generation, recordCount: values.length, migratedFrom: "v7", savedAt: new Date().toISOString() };
  await idbPut(META_STORE, meta, "database");
  return { db: { meta, records: Object.fromEntries(values.map(v => [v.record.id, v.record])) }, logs: [] };
}

async function loadPersisted() {
  try {
    const meta = await idbGet(META_STORE, "database");
    if (meta?.activeGeneration) {
      const active = String(meta.activeGeneration);
      const range = IDBKeyRange.bound(`${active}|`, `${active}|\uffff`);
      const activeRows = await idbGetRange(RECORD_STORE, range);
      if (activeRows.length) {
        const records = {};
        for (const item of activeRows) {
          const record = item.record || item;
          if (record?.id) records[record.id] = record;
        }
        // تنظيف خلفي غير مُعطِّل: يشيل أي أجيال قديمة متراكمة من عمليات سابقة حتى لا يتباطأ
        // فتح التطبيق تدريجياً مع الوقت. لا يمس الجيل النشط الحالي إطلاقاً.
        setTimeout(() => pruneStaleGenerations(active), 1500);
        return { db: { meta: { ...meta, recordCount: Object.keys(records).length }, records }, logs: (await idbGet(LOG_STORE, "items")) || [] };
      }
    }
    const migrated = await migrateOldDatabase();
    if (migrated) return migrated;

    // IndexedDB فارغة أو غير متاحة — جرّب استرجاع النسخة المرآة من localStorage كخط دفاع أخير
    // قبل اعتبار القاعدة فارغة فعلاً.
    const backup = readLocalStorageBackup();
    if (backup?.records && Object.keys(backup.records).length) {
      const generation = makeGeneration();
      const restoredMeta = { ...(backup.meta || {}), activeGeneration: generation, recordCount: Object.keys(backup.records).length, savedAt: new Date().toISOString(), storageVersion: 9, recoveredFromMirror: true };
      // نعيد كتابتها في IndexedDB فوراً حتى تكون هي المصدر الأساسي من هذه اللحظة.
      await persistDB(restoredMeta, backup.records, { replace: true });
      return { db: { meta: restoredMeta, records: backup.records }, logs: [] };
    }
    return { db: null, logs: [] };
  } catch (e) {
    console.error("loadPersisted", e);
    // حتى لو فشلت IndexedDB بالكامل (استثناء غير متوقع)، جرّب المرآة قبل الاستسلام.
    const backup = readLocalStorageBackup();
    if (backup?.records && Object.keys(backup.records).length) {
      return { db: { meta: { ...(backup.meta || {}), recoveredFromMirror: true }, records: backup.records }, logs: [] };
    }
    return { db: null, logs: [] };
  }
}

async function persistDB(meta, records, { replace = false, changedIds = null, deletedIds = [] } = {}) {
  const job = async () => {
    try {
      const currentMeta = meta || {};
      if (replace || !currentMeta.activeGeneration) {
        const generation = makeGeneration();
        const snapshot = Object.values(records || {}).map(r => ({ ...r, observations: getObservations(r).map(o => ({ ...o })) }));
        // الكتابة كلها في generation جديد. القديم يظل صالحاً حتى لحظة اعتماد الجديد.
        for (let i=0;i<snapshot.length;i+=3000) {
          await idbPutBatch(RECORD_STORE, snapshot.slice(i,i+3000).map(record => ({ key: `${generation}|${record.id}`, record })));
        }
        const finalMeta = { ...currentMeta, activeGeneration: generation, recordCount: snapshot.length, savedAt: new Date().toISOString(), storageVersion: 9 };
        // هذه هي نقطة الالتزام الوحيدة: قبلها لا تتغير القاعدة النشطة.
        await idbPut(META_STORE, finalMeta, "database");
        mirrorToLocalStorage(finalMeta, records || {});
        // الجيل الجديد بقى معتمَداً ومحفوظاً؛ الآن آمن نشيل أي أجيال قديمة من عمليات سابقة.
        setTimeout(() => pruneStaleGenerations(generation), 1500);
        return finalMeta;
      }

      const generation = String(currentMeta.activeGeneration);
      const ids = changedIds ? [...new Set(changedIds)] : Object.keys(records || {});
      const values = ids.map(id => records?.[id]).filter(Boolean).map(record => ({
        key: `${generation}|${record.id}`,
        record: { ...record, observations: getObservations(record).map(o => ({ ...o })) },
      }));
      // دفعات صغيرة: أسرع على الهاتف ولا تعيد كتابة الملايين.
      for (let i=0;i<values.length;i+=3000) await idbPutBatch(RECORD_STORE, values.slice(i,i+3000));
      for (const id of [...new Set(deletedIds || [])]) await idbDelete(RECORD_STORE, `${generation}|${id}`);
      const finalMeta = { ...currentMeta, activeGeneration: generation, recordCount: Object.keys(records || {}).length, savedAt: new Date().toISOString(), storageVersion: 9 };
      await idbPut(META_STORE, finalMeta, "database");
      mirrorToLocalStorage(finalMeta, records || {});
      return finalMeta;
    } catch (e) {
      console.error("persistDB", e);
      return false;
    }
  };
  persistQueue = persistQueue.then(job, job);
  return persistQueue;
}

async function persistLogs(logs) {
  try { await idbPut(LOG_STORE, (logs || []).slice(0, 300), "items"); } catch (e) { console.error(e); }
}
async function requestPersistentStorage() {
  try {
    if (navigator.storage?.persist) return await navigator.storage.persist();
  } catch {}
  return false;
}
async function isStoragePersisted() {
  try {
    if (navigator.storage?.persisted) return await navigator.storage.persisted();
  } catch {}
  return null; // غير معروف — المتصفح لا يدعم الفحص
}

/* ============================== نسخة احتياطية مرآة في localStorage ==============================
   خط دفاع ثانٍ مستقل عن IndexedDB. لو IndexedDB اتمسحت أو فشلت لأي سبب (بعض متصفحات
   الواتساب/فيسبوك الداخلية أو أوضاع التصفح الخاص بتمسح مساحات تخزين معيّنة فقط)، بنقدر
   نسترجع آخر نسخة محفوظة هنا تلقائياً عند فتح التطبيق. */
const LS_BACKUP_KEY = "plates_v9_mirror_backup";

function mirrorToLocalStorage(meta, records) {
  try {
    // IndexedDB هو المصدر الأساسي. لا نحاول حتى تحويل القاعدة إلى JSON عند كبرها:
    // stringify لمليون سجل يستهلك ذاكرة ووقتاً وقد يجمّد واجهة الهاتف.
    // مرآة localStorage مخصصة فقط لقواعد صغيرة جداً للاسترداد الطارئ.
    const recordCount = Number(meta?.recordCount ?? Object.keys(records || {}).length);
    const SMALL_BACKUP_MAX_RECORDS = 2000;
    if (recordCount > SMALL_BACKUP_MAX_RECORDS) {
      try { window.localStorage.removeItem(LS_BACKUP_KEY); } catch {}
      return;
    }
    const payload = JSON.stringify({ meta, records, savedAt: new Date().toISOString() });
    if (payload.length > 1_000_000) {
      try { window.localStorage.removeItem(LS_BACKUP_KEY); } catch {}
      return;
    }
    window.localStorage.setItem(LS_BACKUP_KEY, payload);
  } catch (e) {
    // IndexedDB يظل المصدر الأساسي، ولا نوقف حفظ البيانات بسبب المرآة.
    console.warn("localStorage backup skipped", e);
  }
}

function readLocalStorageBackup() {
  try {
    const raw = window.localStorage.getItem(LS_BACKUP_KEY);
    if (!raw) return null;
    const payload = JSON.parse(raw);
    if (!payload?.records || !Object.keys(payload.records).length) return null;
    return payload;
  } catch {
    return null;
  }
}

function clearLocalStorageBackup() {
  try { window.localStorage.removeItem(LS_BACKUP_KEY); } catch {}
}

/* ============================== كشف بيئات المتصفح المعرّضة لفقد البيانات ==============================
   بعض المتصفحات المدمجة داخل تطبيقات أخرى (واتساب، فيسبوك، إنستجرام، ماسنجر...) تفتح الروابط
   في جلسة تخزين مؤقتة قد لا تُبقي البيانات بعد إغلاق الرابط. هذا الفحص تحذيري فقط؛ لا يمكن لأي
   كود على الصفحة تغيير سلوك التخزين في هذه المتصفحات — الحل الوحيد فتح الرابط في متصفح حقيقي.*/
function detectInAppBrowserRisk() {
  try {
    const ua = navigator.userAgent || "";
    const patterns = [
      /FBAN|FBAV|FB_IAB/i,      // فيسبوك/ماسنجر
      /Instagram/i,             // إنستجرام
      /Line\//i,                // Line
      /MicroMessenger/i,        // WeChat
      /Twitter/i,               // X / تويتر
      /TikTok/i,                // تيك توك
      /WhatsApp/i,              // واتساب (نادراً ما يظهر لكن للاحتياط)
    ];
    return patterns.some((p) => p.test(ua));
  } catch {
    return false;
  }
}

/* ============================== استقبال ملف من قائمة المشاركة في أندرويد ============================== */
const SHARE_INBOX_DB = "plates-share-inbox-v1";
const SHARE_INBOX_STORE = "pending";

function openShareInbox() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(SHARE_INBOX_DB, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(SHARE_INBOX_STORE)) db.createObjectStore(SHARE_INBOX_STORE, { keyPath: "id", autoIncrement: true });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("تعذر فتح صندوق المشاركة"));
  });
}

async function takeSharedFile() {
  const db = await openShareInbox();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(SHARE_INBOX_STORE, "readwrite");
    const store = tx.objectStore(SHARE_INBOX_STORE);
    const req = store.getAll();
    req.onsuccess = () => {
      const rows = req.result || [];
      // استخدم أحدث مشاركة فقط، واحذفها من الصندوق بعد القراءة حتى لا تتكرر عند Refresh.
      const latest = rows.sort((a,b) => (b.createdAt || 0) - (a.createdAt || 0))[0] || null;
      for (const row of rows) store.delete(row.id);
      tx.oncomplete = () => { db.close(); resolve(latest); };
    };
    req.onerror = () => { db.close(); reject(req.error || new Error("تعذر قراءة الملف المشترك")); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error("تعذر إتمام قراءة الملف المشترك")); };
  });
}

/* ============================== المكوّن الرئيسي ============================== */
export default function App() {
  const [records, setRecords] = useState({}); // normalized_plate -> record
  const [meta, setMeta] = useState({ baseFileName: null, lastUpdated: null });
  const [logs, setLogs] = useState([]);
  const [tab, setTab] = useState("dashboard");
  const [toast, setToast] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saveState, setSaveState] = useState("saved");
  const [inAppBrowserRisk] = useState(() => detectInAppBrowserRisk());
  const [persistedGranted, setPersistedGranted] = useState(null); // null = غير معروف بعد
  const [bannerDismissed, setBannerDismissed] = useState(false);
  const loadedRef = useRef(false);
  const [sharedFile, setSharedFile] = useState(null);

  const recordList = useMemo(() => Object.values(records), [records]);

  const pushLog = useCallback((action, details, count) => {
    setLogs((prev) => [logEntry(action, details, count), ...prev].slice(0, 200));
  }, []);

  const showToast = useCallback((text, kind = "good") => {
    setToast({ text, kind });
    setTimeout(() => setToast(null), 3200);
  }, []);

  // تحميل البيانات المحفوظة عند فتح التطبيق
  useEffect(() => {
    (async () => {
      const { db, logs: savedLogs } = await loadPersisted();
      if (db && db.records) {
        setRecords(db.records);
        setMeta(db.meta || { baseFileName: null, lastUpdated: null });
        if (db.meta?.recoveredFromMirror) {
          showToast("تم استرجاع البيانات تلقائياً من نسخة احتياطية داخلية بعد أن وجدنا التخزين الرئيسي فارغاً.", "good");
        }
      }
      if (savedLogs && savedLogs.length) setLogs(savedLogs);
      loadedRef.current = true;
      await requestPersistentStorage();
      const granted = await isStoragePersisted();
      setPersistedGranted(granted);
      try {
        const pending = await takeSharedFile();
        if (pending?.file) {
          setSharedFile(pending);
          setTab("wanted");
          showToast(`تم استقبال الملف من المشاركة: ${pending.name || "ملف"}`, "good");
        }
      } catch (e) {
        console.warn("shared file", e);
      }
      setLoading(false);
    })();
  }, [showToast]);

  useEffect(() => {
    if (!loadedRef.current) return;
    persistLogs(logs);
  }, [logs]);

  if (loading) {
    return (
      <div dir="rtl" style={{
        fontFamily: FONT_BODY, background: COLORS.bg, minHeight: "100vh", color: COLORS.ink,
        display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 10,
      }}>
        <style>{`@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@700&display=swap'); @keyframes spin { to { transform: rotate(360deg); } }`}</style>
        <Loader2 size={28} color={COLORS.navy} style={{ animation: "spin 1s linear infinite" }} />
        <div style={{ fontFamily: FONT_HEAD, fontWeight: 700, fontSize: 14 }}>جاري تحميل البيانات المحفوظة...</div>
      </div>
    );
  }

  return (
    <div dir="rtl" style={{ fontFamily: FONT_BODY, background: COLORS.bg, minHeight: "100vh", color: COLORS.ink }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@500;700;800&family=IBM+Plex+Sans+Arabic:wght@400;500;600&display=swap');
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-thumb { background: #C8CFDA; border-radius: 8px; }
        button { font-family: inherit; cursor: pointer; }
        input, select, textarea { font-family: inherit; }
        body { background:#eef2f7; }
        button { transition: transform .12s ease, box-shadow .12s ease, background .12s ease; }
        button:not(:disabled):active { transform: translateY(1px); }
        .app-main { max-width: 1500px; margin: 0 auto; width: 100%; }
        .nav-sidebar { box-shadow: 0 12px 35px rgba(9,25,52,.10); }
        @media (max-width: 819px) {
          .nav-sidebar { position: sticky; top: 0; z-index: 30; overflow-x: auto; flex-wrap: nowrap !important; min-width: 100% !important; padding: 6px; gap: 4px; }
          .nav-sidebar button { width: auto !important; min-width: 118px; justify-content: center; border-radius: 10px; padding: 11px 10px !important; border-right: 0 !important; white-space: nowrap; font-size: 12px !important; }
          .nav-sidebar button svg { display:none; }
          .app-main { padding: 14px !important; }
          .top-stats { display:none !important; }
        }
        @media (min-width: 820px) {
          .nav-sidebar { flex-direction: column !important; }
        }
      `}</style>

      <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
        {/* شريط علوي */}
        <header style={{
          background: COLORS.navyDeep, color: "#fff", padding: "14px 20px",
          display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{
              width: 36, height: 24, borderRadius: 4, background: COLORS.gold,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: FONT_HEAD, fontWeight: 800, fontSize: 12, color: COLORS.navyDeep, letterSpacing: 1,
            }}>ع ١٢٣</div>
            <div>
              <div style={{ fontFamily: FONT_HEAD, fontWeight: 800, fontSize: 16 }}>منظومة إدارة ومطابقة لوحات السيارات</div>
              <div style={{ fontSize: 11.5, color: "#9FB0CC" }}>
                {meta.baseFileName ? `الملف الأساسي: ${meta.baseFileName} — آخر تحديث ${meta.lastUpdated}` : "لا يوجد ملف أساسي محمّل بعد"}
              </div>
            </div>
          </div>
          <div className="top-stats" style={{ fontSize: 12, color: "#9FB0CC", display: "flex", gap: 16, alignItems:"center" }}>
            <span>{recordList.length.toLocaleString("ar-EG")} لوحة</span>
            <span>{recordList.reduce((s, r) => s + r.observations.length, 0).toLocaleString("ar-EG")} رصد</span>
            <span style={{display:"inline-flex",alignItems:"center",gap:5,color:saveState==="error"?"#ffb3aa":saveState==="saving"?"#f4d48b":"#9ee0b8"}}>
              {saveState==="error"?<WifiOff size={13}/>:saveState==="saving"?<HardDrive size={13}/>:<CheckCircle2 size={13}/>}
              {saveState==="error"?"فشل الحفظ":saveState==="saving"?"جاري الحفظ":"محفوظ"}
            </span>
          </div>
        </header>

        {inAppBrowserRisk && !bannerDismissed && (
          <div style={{
            background: "#FFF3F1", borderBottom: `1px solid ${COLORS.bad}`, color: "#8A3A32",
            padding: "10px 20px", display: "flex", alignItems: "center", justifyContent: "space-between",
            gap: 12, flexWrap: "wrap", fontSize: 12.5, lineHeight: 1.7,
          }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
              <TriangleAlert size={16} style={{ flexShrink: 0, marginTop: 1 }} />
              <span>
                يبدو إنك فاتح الموقع من داخل متصفح تطبيق آخر (واتساب/فيسبوك/إنستجرام أو غيره)، وهذه المتصفحات
                أحياناً لا تحتفظ بالبيانات بعد إغلاق الرابط. للأمان: افتح هذا الرابط في <b>Safari</b> أو <b>Chrome</b> مباشرة
                (زر "فتح في المتصفح" غالباً موجود في قائمة الثلاث نقاط)، والأفضل إضافة الموقع للشاشة الرئيسية، وخد نسخة
                احتياطية بشكل دوري من تبويب "الأمان والنسخ الاحتياطي".
              </span>
            </div>
            <button onClick={() => setBannerDismissed(true)} style={{ background: "none", border: "none", color: "#8A3A32", flexShrink: 0 }}>
              <X size={16} />
            </button>
          </div>
        )}
        {!inAppBrowserRisk && persistedGranted === false && !bannerDismissed && (
          <div style={{
            background: "#FFF8E8", borderBottom: `1px solid ${COLORS.gold}`, color: "#6B4E12",
            padding: "10px 20px", display: "flex", alignItems: "center", justifyContent: "space-between",
            gap: 12, flexWrap: "wrap", fontSize: 12.5, lineHeight: 1.7,
          }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
              <TriangleAlert size={16} style={{ flexShrink: 0, marginTop: 1 }} />
              <span>
                المتصفح لم يمنح التطبيق تخزيناً دائماً مضموناً بنسبة ١٠٠٪. البيانات محفوظة الآن، لكن للأمان الإضافي:
                أضف الموقع إلى الشاشة الرئيسية، وخد نسخة احتياطية JSON بشكل دوري من تبويب "الأمان والنسخ الاحتياطي".
              </span>
            </div>
            <button onClick={() => setBannerDismissed(true)} style={{ background: "none", border: "none", color: "#6B4E12", flexShrink: 0 }}>
              <X size={16} />
            </button>
          </div>
        )}

        <div style={{ display: "flex", flex: 1, flexDirection: "row-reverse", flexWrap: "wrap" }}>
          {/* ملاحة جانبية */}
          <nav style={{
            background: COLORS.navy, minWidth: 210, display: "flex",
            flexDirection: "row", flexWrap: "wrap",
          }} className="nav-sidebar">
            {[
              { id: "dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
              { id: "upload", label: "رفع الملف الأساسي", icon: UploadCloud },
              { id: "addfile", label: "إضافة ملف على القاعدة", icon: Layers },
              { id: "wanted", label: "مطابقة السيارات المطلوبة", icon: Siren },
              { id: "browse", label: "استعراض قاعدة البيانات", icon: Database },
              { id: "security", label: "الأمان والنسخ الاحتياطي", icon: ShieldCheck },
            ].map((item) => {
              const Icon = item.icon;
              const active = tab === item.id;
              return (
                <button key={item.id} onClick={() => setTab(item.id)} style={{
                  display: "flex", alignItems: "center", gap: 10, padding: "14px 18px",
                  background: active ? COLORS.navyDeep : "transparent",
                  borderRight: active ? `3px solid ${COLORS.gold}` : "3px solid transparent",
                  color: active ? "#fff" : "#B7C4DB", border: "none", width: "100%",
                  textAlign: "right", fontSize: 14, fontWeight: active ? 700 : 500,
                }}>
                  <Icon size={17} color={active ? COLORS.gold : "#8393B3"} />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* محتوى */}
          <main className="app-main" style={{ flex: 1, minWidth: 280, padding: 20 }}>
            {tab === "dashboard" && <Dashboard records={recordList} meta={meta} logs={logs} />}
            {tab === "upload" && (
              <UploadBase
                onLoaded={async (newRecords, fileName, internalDupes, totalRows) => {
                  const nextMeta = { baseFileName: fileName, lastUpdated: new Date().toLocaleString("ar-EG"), activeGeneration: makeGeneration() };
                  setSaveState("saving");
                  const savedMeta = await persistDB(nextMeta, newRecords, { replace: true });
                  const ok = !!savedMeta;
                  if (ok) {
                    setRecords(newRecords);
                    setMeta(savedMeta);
                    setSaveState("saved");
                    pushLog("رفع ملف أساسي", `${fileName} — كل الصفوف حُفظت، والتكرارات محفوظة كمرات ظهور`, totalRows);
                    showToast(`تم تحميل وحفظ الملف الأساسي: ${Object.keys(newRecords).length.toLocaleString("ar-EG")} لوحة فريدة`, "good");
                    setTab("dashboard");
                  } else {
                    setSaveState("error");
                    showToast("فشل الحفظ؛ لم أغيّر القاعدة الحالية.", "bad");
                  }
                }}
                hasExisting={recordList.length > 0}
              />
            )}
            {tab === "addfile" && (
              <AddFile
                records={records}
                meta={meta}
                setRecords={setRecords}
                setMeta={setMeta}
                pushLog={pushLog}
                showToast={showToast}
              />
            )}
            {tab === "wanted" && (
              <WantedMatch records={records} sharedFile={sharedFile} onSharedConsumed={() => setSharedFile(null)} />
            )}
            {tab === "browse" && (
              <DatabaseBrowser records={records} setRecords={setRecords} pushLog={pushLog} showToast={showToast} />
            )}
            {tab === "security" && (
              <SecurityCenter
                records={records}
                meta={meta}
                logs={logs}
                setRecords={setRecords}
                setMeta={setMeta}
                pushLog={pushLog}
                showToast={showToast}
              />
            )}
          </main>
        </div>
      </div>

      {toast && (
        <div style={{
          position: "fixed", bottom: 20, insetInlineStart: 20, zIndex: 50,
          background: toast.kind === "good" ? COLORS.good : COLORS.bad, color: "#fff",
          padding: "12px 18px", borderRadius: 10, fontSize: 13.5, fontWeight: 600,
          boxShadow: "0 8px 24px rgba(0,0,0,.18)", display: "flex", alignItems: "center", gap: 8,
          maxWidth: 360,
        }}>
          {toast.kind === "good" ? <CheckCircle2 size={16} /> : <AlertTriangle size={16} />}
          {toast.text}
        </div>
      )}

    </div>
  );
}

/* ============================== لوحة التحكم ============================== */
function StatCard({ label, value, sub, accent }) {
  return (
    <div style={{
      background: COLORS.panel, borderRadius: 10, padding: "16px 18px",
      border: `1px solid ${COLORS.line}`, borderTop: `3px solid ${accent || COLORS.navy}`, flex: "1 1 180px",
    }}>
      <div style={{ fontSize: 12.5, color: COLORS.inkMuted, marginBottom: 6 }}>{label}</div>
      <div style={{ fontFamily: FONT_HEAD, fontWeight: 800, fontSize: 26, color: COLORS.ink }}>{value}</div>
      {sub && <div style={{ fontSize: 11.5, color: COLORS.inkMuted, marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

function Dashboard({ records, meta, logs }) {
  const totalUnique = records.length;
  const totalObservations = records.reduce((s, r) => s + r.observations.length, 0);
  const streets = new Set(records.map((r) => r.street).filter(Boolean));
  const duplicatedPlates = records.filter((r) => r.observations.length > 1).length;
  const dupRate = totalUnique ? ((duplicatedPlates / totalUnique) * 100).toFixed(1) : "0.0";

  const typeCounts = useMemo(() => {
    const m = {};
    records.forEach((r) => { const t = r.car_type || "غير محدد"; m[t] = (m[t] || 0) + 1; });
    return Object.entries(m).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, count]) => ({ name, count }));
  }, [records]);

  const streetCounts = useMemo(() => {
    const m = {};
    records.forEach((r) => { const s = r.street || "غير محدد"; m[s] = (m[s] || 0) + 1; });
    return Object.entries(m).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, count]) => ({ name, count }));
  }, [records]);

  if (totalUnique === 0) {
    return (
      <EmptyState
        icon={Database}
        title="لا توجد بيانات بعد"
        text="ابدأ برفع ملف Excel أو CSV يحتوي على لوحات السيارات من تبويب «رفع الملف الأساسي» لتظهر هنا الإحصائيات الحية."
      />
    );
  }

  return (
    <div>
      <SectionTitle title="لوحة التحكم والإحصائيات الحية" />
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 18 }}>
        <StatCard label="إجمالي اللوحات الفريدة" value={totalUnique.toLocaleString("ar-EG")} accent={COLORS.navy} />
        <StatCard label="إجمالي مرات الرصد" value={totalObservations.toLocaleString("ar-EG")} accent={COLORS.gold} />
        <StatCard label="عدد الشوارع/المواقع" value={streets.size.toLocaleString("ar-EG")} accent={COLORS.good} />
        <StatCard label="نسبة اللوحات المكررة الرصد" value={`${dupRate}%`} sub={`${duplicatedPlates.toLocaleString("ar-EG")} لوحة رُصدت أكثر من مرة`} accent={COLORS.bad} />
      </div>

      <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
        <ChartCard title="أكثر أنواع المركبات تكراراً" data={typeCounts} />
        <ChartCard title="أكثر الشوارع/المواقع ازدحاماً" data={streetCounts} />
      </div>

      <div style={{ marginTop: 18 }}>
        <SectionTitle title="آخر العمليات" small />
        <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.line}`, borderRadius: 10, overflow: "hidden" }}>
          {logs.length === 0 ? (
            <div style={{ padding: 16, color: COLORS.inkMuted, fontSize: 13 }}>لا توجد عمليات مسجّلة بعد.</div>
          ) : logs.slice(0, 6).map((l, i) => (
            <div key={i} style={{
              padding: "10px 16px", fontSize: 13, borderBottom: i < 5 ? `1px solid ${COLORS.line}` : "none",
              display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap",
            }}>
              <span><b>{l.action}</b> — {l.details}</span>
              <span style={{ color: COLORS.inkMuted, fontSize: 12 }}>{l.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ChartCard({ title, data }) {
  return (
    <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: 16, flex: "1 1 340px" }}>
      <div style={{ fontSize: 13.5, fontWeight: 700, marginBottom: 10 }}>{title}</div>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={data} layout="vertical" margin={{ left: 10, right: 10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke={COLORS.line} horizontal={false} />
          <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
          <YAxis type="category" dataKey="name" width={100} tick={{ fontSize: 11.5 }} />
          <Tooltip />
          <Bar dataKey="count" radius={[0, 4, 4, 0]}>
            {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

function SectionTitle({ title, small }) {
  return (
    <div style={{
      fontFamily: FONT_HEAD, fontWeight: 800, fontSize: small ? 15 : 19, color: COLORS.navy,
      marginBottom: small ? 8 : 16,
    }}>{title}</div>
  );
}

function EmptyState({ icon: Icon, title, text }) {
  return (
    <div style={{
      background: COLORS.panel, border: `1px dashed ${COLORS.line}`, borderRadius: 12,
      padding: "50px 24px", textAlign: "center", color: COLORS.inkMuted, maxWidth: 520, margin: "40px auto",
    }}>
      <Icon size={30} color={COLORS.gold} style={{ marginBottom: 10 }} />
      <div style={{ fontFamily: FONT_HEAD, fontWeight: 700, fontSize: 16, color: COLORS.ink, marginBottom: 6 }}>{title}</div>
      <div style={{ fontSize: 13.5, lineHeight: 1.7 }}>{text}</div>
    </div>
  );
}

/* ============================== رفع الملف الأساسي ============================== */
function UploadBase({ onLoaded, hasExisting }) {
  const [rows, setRows] = useState(null);
  const [headers, setHeaders] = useState([]);
  const [mapping, setMapping] = useState({ plate: -1, date: -1, street: -1, type: -1 });
  const [fileName, setFileName] = useState("");
  const [unifyDate, setUnifyDate] = useState(false);
  const [customDate, setCustomDate] = useState(todayISO());
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState("");
  const inputRef = useRef(null);

  const handleFile = async (file) => {
    setError("");
    if (!file) return;
    try {
      const parsed = await parseSpreadsheet(file);
      if (!parsed.length) { setError("الملف فارغ أو غير قابل للقراءة."); return; }
      const head = parsed[0];
      setHeaders(head);
      setRows(parsed.slice(1));
      setMapping(detectColumns(head));
      setFileName(file.name);
    } catch (e) {
      setError("تعذّر قراءة الملف. تأكد أنه بصيغة Excel أو CSV صحيحة.");
    }
  };

  const columnValid = mapping.plate !== -1;

  const buildDatabase = () => {
    const map = {};
    let internalDupes = 0;
    let order = 0;
    rows.forEach((row) => {
      const rawPlate = row[mapping.plate];
      if (!rawPlate || !String(rawPlate).trim()) return;
      const normalized = normalizePlate(rawPlate);
      if (!normalized) return;
      // تاريخ الملف الأساسي يُحفظ كما هو تماماً دون أي تعديل؛ تاريخ اليوم
      // يُستخدم فقط لو لم يوجد عمود تاريخ أصلاً في الملف، أو عند اختيار تاريخ موحّد يدوياً.
      const date = unifyDate ? customDate : (mapping.date !== -1 ? normalizeDateValue(row[mapping.date]) : todayISO());
      const street = mapping.street !== -1 ? String(row[mapping.street] || "").trim() : "";
      const carType = mapping.type !== -1 ? String(row[mapping.type] || "").trim() : "";

      if (map[normalized]) {
        internalDupes += 1;
        const rec = map[normalized];
        rec.observations.push({ date, street, car_type: carType, order: order++ });
        if (date && (!rec.last_date || date >= rec.last_date)) { rec.last_date = date; rec.street = street || rec.street; rec.car_type = carType || rec.car_type; }
        if (date && (!rec.first_date || date < rec.first_date)) rec.first_date = date;
      } else {
        map[normalized] = {
          id: normalized, plate_raw: String(rawPlate).trim(), normalized_plate: normalized,
          street, car_type: carType, first_date: date, last_date: date,
          observations: [{ date, street, car_type: carType, order: order++ }],
        };
      }
    });
    onLoaded(map, fileName, internalDupes, rows.length);
  };

  return (
    <div>
      <SectionTitle title="رفع الملف الأساسي" />
      {hasExisting && (
        <div style={{
          background: "#FFF6E6", border: `1px solid ${COLORS.gold}`, borderRadius: 8, padding: "10px 14px",
          fontSize: 13, marginBottom: 14, display: "flex", gap: 8, alignItems: "center",
        }}>
          <TriangleAlert size={16} color={COLORS.gold} />
          يوجد بالفعل ملف أساسي محمّل ومحفوظ. رفع ملف جديد هنا سيستبدل قاعدة البيانات الحالية بالكامل. لإضافة بيانات جديدة دون استبدال، استخدم تبويب «إضافة ملف على القاعدة».
        </div>
      )}

      {!rows && (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files[0]); }}
          onClick={() => inputRef.current?.click()}
          style={{
            border: `2px dashed ${dragOver ? COLORS.navy : COLORS.line}`, borderRadius: 12,
            background: dragOver ? "#F0F4FA" : COLORS.panel, padding: "48px 20px", textAlign: "center",
            cursor: "pointer", maxWidth: 560,
          }}
        >
          <UploadCloud size={32} color={COLORS.navy} style={{ marginBottom: 10 }} />
          <div style={{ fontWeight: 700, marginBottom: 4 }}>اسحب وأفلت ملف Excel أو CSV هنا</div>
          <div style={{ fontSize: 12.5, color: COLORS.inkMuted }}>أو اضغط للاختيار من جهازك — يدعم .xlsx و .xls و .csv</div>
          <input ref={inputRef} type="file" accept=".xlsx,.xls,.csv" hidden onChange={(e) => handleFile(e.target.files[0])} />
        </div>
      )}

      {error && <div style={{ color: COLORS.bad, fontSize: 13, marginTop: 10 }}>{error}</div>}

      {rows && (
        <div style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 16, maxWidth: 640 }}>
          <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: 16 }}>
            <div style={{ fontWeight: 700, marginBottom: 10, fontSize: 14 }}>
              الملف: {fileName} — {rows.length.toLocaleString("ar-EG")} صف
            </div>
            <div style={{ fontSize: 12.5, color: COLORS.inkMuted, marginBottom: 10 }}>
              تحديد الأعمدة (اللوحة والتاريخ والشارع والنوع الأساسي فقط):
            </div>
            {["plate", "date", "street", "type"].map((key) => (
              <ColumnMapRow
                key={key}
                label={{ plate: "عمود اللوحة *", date: "عمود التاريخ", street: "عمود الشارع/الموقع", type: "عمود النوع الأساسي" }[key]}
                headers={headers}
                value={mapping[key]}
                onChange={(v) => setMapping((m) => ({ ...m, [key]: v }))}
              />
            ))}
          </div>

          <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: 16 }}>
            <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13.5, cursor: "pointer" }}>
              <input type="checkbox" checked={unifyDate} onChange={(e) => setUnifyDate(e.target.checked)} />
              تطبيق تاريخ موحّد على جميع صفوف الملف
            </label>
            {unifyDate && (
              <input type="date" value={customDate} onChange={(e) => setCustomDate(e.target.value)}
                style={{ marginTop: 10, padding: "8px 10px", border: `1px solid ${COLORS.line}`, borderRadius: 6, fontSize: 13 }} />
            )}
          </div>

          {!columnValid && <div style={{ color: COLORS.bad, fontSize: 13 }}>يجب تحديد عمود اللوحة للمتابعة.</div>}

          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={buildDatabase} disabled={!columnValid} style={primaryBtn(!columnValid)}>
              <Save size={15} /> اعتماد الملف كقاعدة أساسية
            </button>
            <button onClick={() => { setRows(null); setHeaders([]); setFileName(""); }} style={ghostBtn()}>
              إلغاء واختيار ملف آخر
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function ColumnMapRow({ label, headers, value, onChange }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8, flexWrap: "wrap" }}>
      <div style={{ fontSize: 13, width: 150 }}>{label}</div>
      <select value={value} onChange={(e) => onChange(Number(e.target.value))}
        style={{ padding: "7px 10px", borderRadius: 6, border: `1px solid ${COLORS.line}`, fontSize: 13, flex: 1, minWidth: 160 }}>
        <option value={-1}>— غير محدد —</option>
        {headers.map((h, i) => <option key={i} value={i}>{String(h) || `عمود ${i + 1}`}</option>)}
      </select>
    </div>
  );
}

function primaryBtn(disabled) {
  return {
    display: "flex", alignItems: "center", gap: 6, background: disabled ? "#A8B3C4" : COLORS.navy,
    color: "#fff", border: "none", borderRadius: 8, padding: "10px 18px", fontSize: 13.5, fontWeight: 700,
    cursor: disabled ? "not-allowed" : "pointer",
  };
}
function ghostBtn() {
  return {
    display: "flex", alignItems: "center", gap: 6, background: "transparent", color: COLORS.ink,
    border: `1px solid ${COLORS.line}`, borderRadius: 8, padding: "10px 18px", fontSize: 13.5, fontWeight: 600,
  };
}
function dangerBtn() {
  return {
    display: "flex", alignItems: "center", gap: 6, background: COLORS.bad, color: "#fff",
    border: "none", borderRadius: 8, padding: "10px 18px", fontSize: 13.5, fontWeight: 700,
  };
}

/* ============================== إضافة ملف على القاعدة الأساسية ============================== */
function AddFile({ records, meta, setRecords, setMeta, pushLog, showToast }) {
  const [rows, setRows] = useState(null);
  const [headers, setHeaders] = useState([]);
  const [mapping, setMapping] = useState({ plate: -1, street: -1, type: -1 });
  const [fileName, setFileName] = useState("");
  const [report, setReport] = useState(null);
  const inputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState("");

  const hasBase = Object.keys(records).length > 0;

  const handleFile = async (file) => {
    setError(""); setReport(null);
    if (!file) return;
    try {
      const parsed = await parseSpreadsheet(file);
      if (!parsed.length) { setError("الملف فارغ أو غير قابل للقراءة."); return; }
      setHeaders(parsed[0]);
      setRows(parsed.slice(1));
      const detected = detectColumns(parsed[0]);
      setMapping({ plate: detected.plate, street: detected.street, type: detected.type });
      setFileName(file.name);
    } catch {
      setError("تعذّر قراءة الملف.");
    }
  };

  // يضيف كل صف في الملف بالكامل دون أي تجاهل، حتى لو كانت اللوحة مكررة
  // (سواء مع القاعدة أو داخل الملف نفسه). كل إضافة تُسجَّل بتاريخ اليوم،
  // وبيانات اللوحة القديمة (إن وُجدت) تبقى كما هي دون أي تعديل.
  const runAdd = async () => {
    const updated = { ...records };
    let newCount = 0, existingCount = 0, internalDup = 0;
    const seenThisFile = new Set();
    const changedIds = new Set();
    const newPlatesList = [], existingPlatesList = [];
    const today = todayISO();
    let order = Object.values(records).flatMap(r => getObservations(r).map(o => o.order ?? -1)).reduce((m, v) => Math.max(m, v), -1) + 1;

    rows.forEach((row) => {
      const rawPlate = row[mapping.plate];
      if (!rawPlate || !String(rawPlate).trim()) return;
      const normalized = normalizePlate(rawPlate);
      if (!normalized) return;
      if (seenThisFile.has(normalized)) internalDup += 1;
      seenThisFile.add(normalized);

      const street = mapping.street !== -1 ? String(row[mapping.street] || "").trim() : "";
      const carType = mapping.type !== -1 ? String(row[mapping.type] || "").trim() : "";

      if (updated[normalized]) {
        // موجودة من قبل: تُضاف كرصد جديد بتاريخ اليوم، والبيانات الأصلية للسجل تبقى كما هي
        existingCount += 1;
        changedIds.add(normalized);
        existingPlatesList.push({ "اللوحة": rawPlate, "الشارع/الموقع الجديد": street, "تاريخ الإضافة": today });
        const rec = updated[normalized];
        const newObs = { date: today, street, car_type: carType, order: order++ };
        updated[normalized] = {
          ...rec,
          street: street || rec.street,
          car_type: carType || rec.car_type,
          last_date: today,
          observations: [...getObservations(rec), newObs]
        };
      } else {
        newCount += 1;
        changedIds.add(normalized);
        newPlatesList.push({ "اللوحة": rawPlate, "الشارع/الموقع": street, "تاريخ الإضافة": today });
        updated[normalized] = {
          id: normalized, plate_raw: String(rawPlate).trim(), normalized_plate: normalized,
          street, car_type: carType, first_date: today, last_date: today,
          observations: [{ date: today, street, car_type: carType, order: order++ }],
        };
      }
    });

    const nextMeta = { ...(meta || {}), lastUpdated: new Date().toLocaleString("ar-EG") };
    // الحفظ الفعلي يتم قبل إعلان نجاح العملية، وليس فقط بعد setState.
    const savedMeta = await persistDB(nextMeta, updated, { changedIds: [...changedIds] });
    if (!savedMeta) {
      showToast("فشل حفظ الملف المضاف. القاعدة الحالية لم تتغير.", "bad");
      return;
    }
    setRecords(updated);
    setMeta(savedMeta);
    setReport({ total: rows.length, newCount, existingCount, internalDup, newPlatesList, existingPlatesList, fileName });
    pushLog("إضافة ملف على القاعدة", `${fileName} — جديد ${newCount} / موجود مسبقاً ${existingCount} (بتاريخ اليوم)`, rows.length);
    showToast(`تمت إضافة وحفظ كل السجلات (${rows.length.toLocaleString("ar-EG")}) بتاريخ اليوم`);
  };

  if (!hasBase) {
    return <EmptyState icon={Layers} title="لا توجد قاعدة بيانات أساسية" text="يجب رفع الملف الأساسي أولاً من تبويب «رفع الملف الأساسي» قبل إضافة أي ملف عليها." />;
  }

  return (
    <div>
      <SectionTitle title="إضافة ملف جديد على القاعدة الأساسية" />
      <div style={{
        background: "#EFF6F1", border: `1px solid ${COLORS.good}`, borderRadius: 8, padding: "10px 14px",
        fontSize: 13, marginBottom: 14, maxWidth: 640, lineHeight: 1.7,
      }}>
        كل صف في الملف يُضاف بالكامل دون أي تجاهل، حتى لو كانت اللوحة مكررة مع القاعدة أو داخل الملف نفسه.
        كل إضافة تُسجَّل تلقائياً <b>بتاريخ اليوم</b>، وبيانات اللوحات القديمة تبقى كما هي دون أي تعديل. كل شيء يُحفظ تلقائياً فور الإضافة.
      </div>

      {!rows && (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files[0]); }}
          onClick={() => inputRef.current?.click()}
          style={{
            border: `2px dashed ${dragOver ? COLORS.navy : COLORS.line}`, borderRadius: 12,
            background: dragOver ? "#F0F4FA" : COLORS.panel, padding: "40px 20px", textAlign: "center",
            cursor: "pointer", maxWidth: 560,
          }}
        >
          <Layers size={28} color={COLORS.navy} style={{ marginBottom: 8 }} />
          <div style={{ fontWeight: 700 }}>اسحب وأفلت الملف المراد إضافته هنا</div>
          <div style={{ fontSize: 12.5, color: COLORS.inkMuted, marginTop: 4 }}>سيتم دمجه فوق القاعدة الأساسية الحالية بتاريخ اليوم</div>
          <input ref={inputRef} type="file" accept=".xlsx,.xls,.csv" hidden onChange={(e) => handleFile(e.target.files[0])} />
        </div>
      )}

      {error && <div style={{ color: COLORS.bad, fontSize: 13, marginTop: 10 }}>{error}</div>}

      {rows && !report && (
        <div style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 16, maxWidth: 640 }}>
          <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: 16 }}>
            <div style={{ fontWeight: 700, marginBottom: 10 }}>{fileName} — {rows.length.toLocaleString("ar-EG")} صف</div>
            {["plate", "street", "type"].map((key) => (
              <ColumnMapRow
                key={key}
                label={{ plate: "عمود اللوحة *", street: "عمود الشارع/الموقع", type: "عمود النوع الأساسي" }[key]}
                headers={headers}
                value={mapping[key]}
                onChange={(v) => setMapping((m) => ({ ...m, [key]: v }))}
              />
            ))}
            <div style={{ fontSize: 12, color: COLORS.inkMuted, marginTop: 6 }}>
              التاريخ: هيتسجل تلقائياً بتاريخ اليوم ({todayISO()}) لكل السجلات، بدون الحاجة لعمود تاريخ في الملف.
            </div>
          </div>

          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={runAdd} disabled={mapping.plate === -1} style={primaryBtn(mapping.plate === -1)}>
              <Layers size={15} /> إضافة الملف إلى القاعدة
            </button>
            <button onClick={() => { setRows(null); setHeaders([]); }} style={ghostBtn()}>إلغاء</button>
          </div>
        </div>
      )}

      {report && (
        <div style={{ marginTop: 18, maxWidth: 720 }}>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 16 }}>
            <StatCard label="إجمالي السجلات في الملف" value={report.total.toLocaleString("ar-EG")} accent={COLORS.navy} />
            <StatCard label="لوحات جديدة أُضيفت" value={report.newCount.toLocaleString("ar-EG")} accent={COLORS.good} />
            <StatCard label="موجودة مسبقاً (أُضيف رصد لها)" value={report.existingCount.toLocaleString("ar-EG")} accent={COLORS.gold} />
            <StatCard label="مكررة داخل الملف نفسه" value={report.internalDup.toLocaleString("ar-EG")} accent={COLORS.bad} />
          </div>
          <div style={{ fontSize: 13, color: COLORS.inkMuted, marginBottom: 14 }}>
            تم حفظ التغييرات تلقائياً في القاعدة الأساسية — كل السجلات ({report.total.toLocaleString("ar-EG")}) أُضيفت دون أي تجاهل، بتاريخ اليوم.
          </div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <button style={primaryBtn(false)} onClick={() =>
              exportRecordsToExcel(Object.values(records), `تقرير_إضافة_${todayISO()}.xlsx`, [
                { name: "اللوحات الجديدة", rows: report.newPlatesList },
                { name: "لوحات موجودة مسبقاً", rows: report.existingPlatesList },
              ])
            }>
              <FileDown size={15} /> تصدير تقرير الإضافة
            </button>
            <button style={ghostBtn()} onClick={() => { setRows(null); setReport(null); setHeaders([]); }}>
              إضافة ملف آخر
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ============================== مطابقة السيارات المطلوبة ============================== */
function WantedMatch({ records, sharedFile, onSharedConsumed }) {
  const [rows, setRows] = useState(null);
  const [headers, setHeaders] = useState([]);
  const [mapping, setMapping] = useState({ plate: -1, note: -1, type: -1, company: -1, vin: -1 });
  const [fileName, setFileName] = useState("");
  const [result, setResult] = useState(null);
  const [mode, setMode] = useState("file");
  const [pasteText, setPasteText] = useState("");
  const inputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState("");
  const [quickPlate, setQuickPlate] = useState("");
  const [quickResult, setQuickResult] = useState(undefined);
  const hasBase = Object.keys(records).length > 0;

  const runQuickSearch = () => {
    if (!quickPlate.trim()) return;
    const rec = records[normalizePlate(quickPlate)] || null;
    setQuickResult(rec ? { rec, context: getContextAroundLastOccurrence(records, rec, 4) } : null);
  };

  const ContextList = ({ title, items }) => (
    <div style={{background:"#fff",border:`1px solid ${COLORS.line}`,borderRadius:10,padding:10}}>
      <div style={{fontSize:12,fontWeight:800,marginBottom:7}}>{title}</div>
      {items.length ? items.map((x,i)=><div key={i} style={{padding:"7px 0",borderBottom:i<items.length-1?`1px solid ${COLORS.line}`:"none",fontSize:12}}>
        <b>{x.plate}</b> · {x.date||"—"} · {x.street||"—"} · {x.car_type||"—"}
      </div>) : <div style={{fontSize:12,color:COLORS.inkMuted}}>لا توجد سجلات كافية.</div>}
    </div>
  );

  const detectWantedColumns = (headerRow, dataRows) => smartDetectMatchColumns(headerRow, dataRows);

  const handleFile = async (file) => {
    setError(""); setResult(null);
    if (!file) return;
    try {
      const parsed = await parseSpreadsheet(file);
      if (!parsed.length) { setError("الملف فارغ أو غير قابل للقراءة."); return; }
      setHeaders(parsed[0]);
      setRows(parsed.slice(1));
      setMapping(detectWantedColumns(parsed[0], parsed.slice(1)));
      setFileName(file.name);
    } catch {
      setError("تعذّر قراءة الملف. تأكد أنه Excel/CSV صالح.");
    }
  };

  // لو التطبيق اتفتح نتيجة "مشاركة" من واتساب/مدير الملفات، يستقبل الملف تلقائياً هنا.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!sharedFile?.file) return;
      try {
        const blob = sharedFile.file;
        const file = blob instanceof File
          ? blob
          : new File([blob], sharedFile.name || "ملف-مطابقة.xlsx", { type: sharedFile.type || blob.type || "application/octet-stream" });
        if (!cancelled) {
          setMode("file");
          await handleFile(file);
          onSharedConsumed?.();
        }
      } catch (e) {
        console.error("shared file import", e);
        if (!cancelled) setError("تم استقبال الملف من المشاركة لكن تعذرت قراءته. جرّب فتحه من زر رفع الملف.");
        onSharedConsumed?.();
      }
    })();
    return () => { cancelled = true; };
  }, [sharedFile]);

  const parsePaste = () => {
    const lines = pasteText.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    const parsed = [];
    lines.forEach(line => {
      // يدعم: لوحة فقط، أو لوحة<TAB>شركة<TAB>نوع<TAB>ملاحظة
      const cells = line.includes("\t") ? line.split("\t") : [line];
      const raw = (cells[0] || "").trim();
      if (!raw) return;
      parsed.push({
        plate: raw,
        company: (cells[1] || "").trim(),
        type: (cells[2] || "").trim(),
        note: (cells[3] || "").trim()
      });
    });
    return parsed;
  };

  const runMatch = () => {
    const found = [], notFound = [];
    const sourceRows = mode === "paste"
      ? parsePaste().map(x => [x.plate, x.company, x.type, x.note])
      : rows || [];
    const m = mode === "paste"
      ? { plate: 0, company: 1, type: 2, note: 3, vin: -1 }
      : mapping;

    sourceRows.forEach((row) => {
      const rawPlate = row[m.plate];
      if (!rawPlate || !String(rawPlate).trim()) return;
      const normalized = normalizePlate(rawPlate);
      const note = m.note !== -1 ? String(row[m.note] || "").trim() : "";
      const fileType = m.type !== -1 ? String(row[m.type] || "").trim() : "";
      const fileCompany = m.company !== -1 ? String(row[m.company] || "").trim() : "";
      const fileVin = m.vin !== -1 ? String(row[m.vin] || "").trim() : "";
      const rec = records[normalized];
      if (rec) {
        const latest = getLatestObservation(rec);
        found.push({
          "اللوحة المطلوبة": String(rawPlate).trim(),
          "الشركة في ملف المطابقة": fileCompany,
          "النوع في ملف المطابقة": fileType,
          "رقم الشاص (VIN)": fileVin,
          "ملاحظة": note,
          "آخر شارع/موقع": latest.street || "",
          "النوع الأساسي بالقاعدة": latest.car_type || "",
          "آخر تاريخ رصد": latest.date || "",
          "مرات الرصد": getObservations(rec).length,
        });
      } else {
        notFound.push({
          "اللوحة المطلوبة": String(rawPlate).trim(),
          "الشركة في ملف المطابقة": fileCompany,
          "النوع في ملف المطابقة": fileType,
          "رقم الشاص (VIN)": fileVin,
          "ملاحظة": note
        });
      }
    });
    found.sort((a, b) => (b["آخر تاريخ رصد"] || "").localeCompare(a["آخر تاريخ رصد"] || ""));
    setResult({ found, notFound, total: found.length + notFound.length });
  };

  if (!hasBase) return <EmptyState icon={Siren} title="لا توجد قاعدة بيانات أساسية" text="ارفع الملف الأساسي أولاً قبل إجراء المطابقة." />;

  return (
    <div>
      <SectionTitle title="مطابقة السيارات المطلوبة" />

      <div style={{ background: "linear-gradient(135deg,#10213f,#18345d)", color:"#fff", borderRadius:18, padding:20, marginBottom:18, boxShadow:"0 10px 30px rgba(18,33,64,.12)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:14 }}>
          <div style={{ width:42,height:42,borderRadius:12,background:"rgba(255,255,255,.12)",display:"grid",placeItems:"center" }}><Siren size={21} color={COLORS.gold}/></div>
          <div>
            <div style={{fontFamily:FONT_HEAD,fontSize:18,fontWeight:800}}>ابحث عن السيارات المطلوبة</div>
            <div style={{fontSize:12,color:"#b9c7dc"}}>ارفع Excel أو الصق اللوحات مباشرة</div>
          </div>
        </div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          <button onClick={()=>setMode("file")} style={{...ghostBtn(),background:mode==="file"?"#fff":"transparent",color:mode==="file"?COLORS.navy:"#fff",borderColor:"#ffffff55"}}><UploadCloud size={15}/> ملف Excel / CSV</button>
          <button onClick={()=>setMode("paste")} style={{...ghostBtn(),background:mode==="paste"?"#fff":"transparent",color:mode==="paste"?COLORS.navy:"#fff",borderColor:"#ffffff55"}}><ClipboardPaste size={15}/> لصق نص</button>
        </div>
      </div>

      <div style={{ background: COLORS.panel, border:`1px solid ${COLORS.line}`, borderRadius:14, padding:16, marginBottom:18, maxWidth:760 }}>
        <div style={{fontWeight:800,marginBottom:10}}>بحث سريع عن لوحة واحدة</div>
        <div style={{display:"flex",gap:8}}>
          <input value={quickPlate} onChange={e=>{setQuickPlate(e.target.value);setQuickResult(undefined)}} onKeyDown={e=>e.key==="Enter"&&runQuickSearch()} placeholder="مثال: ر ب د 1234" style={{...inputStyle(),flex:1}}/>
          <button style={primaryBtn(!quickPlate.trim())} disabled={!quickPlate.trim()} onClick={runQuickSearch}><Search size={15}/> بحث</button>
        </div>
        {quickResult !== undefined && (
          <div style={{marginTop:12,padding:14,borderRadius:12,background:quickResult?"#FFF3F1":"#EFF6F1",border:`1px solid ${quickResult?COLORS.bad:COLORS.good}`}}>
            {quickResult ? (() => {
              const rec = quickResult.rec; const obs = getObservations(rec); const latest = getLatestObservation(rec);
              return <div>
                <div style={{display:"flex",justifyContent:"space-between",gap:10,flexWrap:"wrap"}}>
                  <div><b style={{color:COLORS.bad}}>موجودة ✓</b> — <b>{rec.plate_raw}</b></div>
                  <div style={{fontSize:12,color:COLORS.inkMuted}}>إجمالي مرات الظهور: {obs.length.toLocaleString("ar-EG")}</div>
                </div>
                <div style={{marginTop:10,padding:10,borderRadius:9,background:"#fff",border:`1px solid ${COLORS.line}`}}>
                  <b>أحدث ظهور فقط</b> — {latest.date||"—"} · {latest.street||"—"} · النوع الأساسي: {latest.car_type||"—"}
                </div>
                <div style={{marginTop:14,fontWeight:800}}>كل مرات الظهور</div>
                <div style={{overflowX:"auto",marginTop:7}}>
                  <table style={{width:"100%",borderCollapse:"collapse",fontSize:12,minWidth:560}}>
                    <thead><tr style={{background:"#fff"}}>{["#","التاريخ","الشارع/الموقع","النوع الأساسي"].map(h=><th key={h} style={{padding:"7px 8px",textAlign:"right",borderBottom:`1px solid ${COLORS.line}`}}>{h}</th>)}</tr></thead>
                    <tbody>{obs.slice().sort((a,b)=>(a.order??0)-(b.order??0)).map((o,i)=><tr key={i} style={{borderBottom:`1px solid ${COLORS.line}`}}><td style={{padding:"7px 8px"}}>{i+1}</td><td style={{padding:"7px 8px"}}>{o.date||"—"}</td><td style={{padding:"7px 8px"}}>{o.street||"—"}</td><td style={{padding:"7px 8px"}}>{o.car_type||"—"}</td></tr>)}</tbody>
                  </table>
                </div>
                <div style={{marginTop:14,fontWeight:800}}>4 لوحات قبل وآخر 4 لوحات بعد <span style={{fontWeight:500,color:COLORS.inkMuted}}>آخر ظهور فقط</span></div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(230px,1fr))",gap:10,marginTop:8}}>
                  <ContextList title="قبل آخر ظهور" items={quickResult.context.before} />
                  <ContextList title="بعد آخر ظهور" items={quickResult.context.after} />
                </div>
              </div>;
            })() : <b style={{color:COLORS.good}}>غير موجودة في القاعدة</b>}
          </div>
        )}
      </div>

      {mode === "file" ? (
        <>
          <div style={{background:"#FFF8EA",border:`1px solid ${COLORS.gold}`,borderRadius:12,padding:"11px 14px",fontSize:13,lineHeight:1.7,marginBottom:14}}>
            ملف المطابقة مستقل عن الملف الأساسي: <b>الشركة</b> و<b>النوع/الموديل</b> و<b>VIN</b> يتم التعرف عليهم من ملف المطابقة فقط، بينما <b>النوع الأساسي</b> يأتي من قاعدة البيانات ولا يتم استبداله.
          </div>
          {!rows && (
            <div onDragOver={e=>{e.preventDefault();setDragOver(true)}} onDragLeave={()=>setDragOver(false)} onDrop={e=>{e.preventDefault();setDragOver(false);handleFile(e.dataTransfer.files[0])}} onClick={()=>inputRef.current?.click()}
              style={{border:`2px dashed ${dragOver?COLORS.bad:COLORS.line}`,borderRadius:16,background:dragOver?"#FFF3F1":COLORS.panel,padding:"46px 20px",textAlign:"center",cursor:"pointer",maxWidth:700}}>
              <UploadCloud size={32} color={COLORS.navy}/>
              <div style={{fontWeight:800,marginTop:8}}>ارفع ملف المطابقة</div>
              <div style={{fontSize:12.5,color:COLORS.inkMuted,marginTop:4}}>Excel / CSV — اللوحة إجبارية، الشركة والنوع والملاحظة اختيارية</div>
              <input ref={inputRef} type="file" accept=".xlsx,.xls,.csv" hidden onChange={e=>handleFile(e.target.files[0])}/>
            </div>
          )}
          {rows && !result && (
            <div style={{marginTop:16,background:COLORS.panel,border:`1px solid ${COLORS.line}`,borderRadius:14,padding:16,maxWidth:700}}>
              <div style={{fontWeight:800,marginBottom:12}}>{fileName} — {rows.length.toLocaleString("ar-EG")} صف</div>
              <div style={{background:"#EFF6F1",border:`1px solid ${COLORS.good}`,borderRadius:10,padding:"10px 12px",fontSize:12.5,lineHeight:1.7,marginBottom:10}}>
                تم التعرف تلقائياً على اللوحة والشركة ونوع/موديل المركبة ورقم الشاص (VIN) من أسماء الأعمدة وشكل البيانات. مثلاً «النترا، هيلوكس، كورولا» تُعامل كنوع/موديل في ملف المطابقة. يمكنك تعديل أي اختيار يدوياً إذا احتجت.
              </div>
              <ColumnMapRow label="عمود اللوحة *" headers={headers} value={mapping.plate} onChange={v=>setMapping(m=>({...m,plate:v}))}/>
              <ColumnMapRow label="عمود الشركة / الجهة" headers={headers} value={mapping.company} onChange={v=>setMapping(m=>({...m,company:v}))}/>
              <ColumnMapRow label="عمود النوع في ملف المطابقة" headers={headers} value={mapping.type} onChange={v=>setMapping(m=>({...m,type:v}))}/>
              <ColumnMapRow label="عمود رقم الشاص (VIN)" headers={headers} value={mapping.vin} onChange={v=>setMapping(m=>({...m,vin:v}))}/>
              <ColumnMapRow label="عمود الملاحظة" headers={headers} value={mapping.note} onChange={v=>setMapping(m=>({...m,note:v}))}/>
              <div style={{display:"flex",gap:10,marginTop:14}}>
                <button onClick={runMatch} disabled={mapping.plate===-1} style={primaryBtn(mapping.plate===-1)}><Siren size={15}/> تشغيل المطابقة</button>
                <button onClick={()=>{setRows(null);setHeaders([])}} style={ghostBtn()}>إلغاء</button>
              </div>
            </div>
          )}
        </>
      ) : (
        <div style={{background:COLORS.panel,border:`1px solid ${COLORS.line}`,borderRadius:14,padding:16,maxWidth:700}}>
          <div style={{fontWeight:800,marginBottom:6}}>لصق اللوحات</div>
          <div style={{fontSize:12,color:COLORS.inkMuted,marginBottom:10,lineHeight:1.7}}>
            لوحة واحدة في كل سطر. ويمكنك اختيارياً لصق: <b>اللوحة ثم الشركة ثم النوع ثم الملاحظة</b> مفصولة بـ Tab.
          </div>
          <textarea value={pasteText} onChange={e=>{setPasteText(e.target.value);setResult(null)}} placeholder={"ربد1234\nسحط5678\n\nأو:\nربد1234\tتويوتا\tونيت\tمطلوبة"} style={{width:"100%",minHeight:210,padding:14,borderRadius:12,border:`1px solid ${COLORS.line}`,resize:"vertical",fontFamily:"inherit",fontSize:14,lineHeight:1.8}}/>
          <div style={{display:"flex",gap:10,marginTop:12}}>
            <button onClick={runMatch} disabled={!pasteText.trim()} style={primaryBtn(!pasteText.trim())}><Siren size={15}/> مطابقة النص</button>
            <button onClick={()=>{setPasteText("");setResult(null)}} style={ghostBtn()}>مسح</button>
          </div>
        </div>
      )}

      {error && <div style={{color:COLORS.bad,fontSize:13,marginTop:10}}>{error}</div>}

      {result && (
        <div style={{marginTop:20}}>
          <div style={{display:"flex",gap:12,flexWrap:"wrap",marginBottom:16}}>
            <StatCard label="إجمالي المطلوب" value={result.total.toLocaleString("ar-EG")} accent={COLORS.navy}/>
            <StatCard label="موجودة" value={result.found.length.toLocaleString("ar-EG")} accent={COLORS.bad}/>
            <StatCard label="غير موجودة" value={result.notFound.length.toLocaleString("ar-EG")} accent={COLORS.good}/>
          </div>
          {result.found.length>0 && <div style={{background:COLORS.panel,border:`1px solid ${COLORS.line}`,borderRadius:14,overflow:"auto",marginBottom:14}}>
            <table style={{width:"100%",borderCollapse:"collapse",fontSize:12.5,minWidth:980}}>
              <thead><tr style={{background:"#FFF3F1",textAlign:"right"}}>
                {["اللوحة","الشركة في الملف","النوع/الموديل في الملف","النوع الأساسي بالقاعدة","VIN / الشاص","الشارع","آخر رصد","المرات","ملاحظة"].map(h=><th key={h} style={{padding:"10px 12px",borderBottom:`1px solid ${COLORS.line}`}}>{h}</th>)}
              </tr></thead>
              <tbody>{result.found.map((f,i)=><tr key={i} style={{borderBottom:`1px solid ${COLORS.line}`}}>
                <td style={{padding:"9px 12px",fontFamily:FONT_HEAD,fontWeight:800}}>{f["اللوحة المطلوبة"]}</td>
                <td style={{padding:"9px 12px"}}>{f["الشركة في ملف المطابقة"]||"—"}</td>
                <td style={{padding:"9px 12px"}}>{f["النوع في ملف المطابقة"]||"—"}</td>
                <td style={{padding:"9px 12px"}}>{f["النوع الأساسي بالقاعدة"]||"—"}</td>
                <td style={{padding:"9px 12px",fontFamily:"monospace"}}>{f["رقم الشاص (VIN)"]||"—"}</td>
                <td style={{padding:"9px 12px"}}>{f["آخر شارع/موقع"]||"—"}</td>
                <td style={{padding:"9px 12px"}}>{f["آخر تاريخ رصد"]||"—"}</td>
                <td style={{padding:"9px 12px"}}>{f["مرات الرصد"]}</td>
                <td style={{padding:"9px 12px"}}>{f["ملاحظة"]||"—"}</td>
              </tr>)}</tbody>
            </table>
          </div>}
          <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
            <button style={primaryBtn(false)} onClick={()=>{
              const wb=XLSX.utils.book_new();
              XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(result.found),"موجودة");
              XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(result.notFound),"غير موجودة");
              XLSX.writeFile(wb,`تقرير_مطابقة_${todayISO()}.xlsx`);
            }}><FileDown size={15}/> تصدير التقرير</button>
            <button style={ghostBtn()} onClick={()=>{setResult(null);setRows(null);setPasteText("");setHeaders([])}}>مطابقة جديدة</button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ============================== استعراض قاعدة البيانات ============================== */
const PAGE_SIZE = 25;

function DatabaseBrowser({ records, setRecords, pushLog, showToast }) {
  const [q, setQ] = useState("");
  const [street, setStreet] = useState("");
  const [type, setType] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState(null);

  const list = useMemo(() => Object.values(records), [records]);
  const streets = useMemo(() => [...new Set(list.map((r) => r.street).filter(Boolean))].sort(), [list]);
  const types = useMemo(() => [...new Set(list.map((r) => r.car_type).filter(Boolean))].sort(), [list]);

  const filtered = useMemo(() => {
    const nq = normalizePlate(q);
    return list.filter((r) => {
      if (nq && !(r.normalized_plate.includes(nq) || normalizePlate(r.plate_raw).includes(nq))) return false;
      if (street && r.street !== street) return false;
      if (type && r.car_type !== type) return false;
      if (dateFrom && r.last_date < dateFrom) return false;
      if (dateTo && r.last_date > dateTo) return false;
      return true;
    });
  }, [list, q, street, type, dateFrom, dateTo]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageRows = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const deleteRecord = async (id) => {
    const rec = records[id];
    const next = { ...records };
    delete next[id];
    const metaNext = { activeGeneration: undefined };
    const current = await idbGet(META_STORE, "database");
    const savedMeta = current?.activeGeneration ? await persistDB({ ...current, lastUpdated: new Date().toLocaleString("ar-EG") }, next, { changedIds: [], deletedIds: [id] }) : false;
    if (!savedMeta) { showToast("فشل حفظ الحذف. لم يتم تغيير السجل.", "bad"); return; }
    setRecords(next);
    setMeta(savedMeta);
    pushLog("حذف سجل", `اللوحة ${rec.plate_raw}`, 1);
    showToast("تم حذف السجل وحفظه");
  };

  const saveEdit = async (updatedRec) => {
    const next = { ...records, [updatedRec.id]: updatedRec };
    const current = await idbGet(META_STORE, "database");
    const savedMeta = current?.activeGeneration ? await persistDB({ ...current, lastUpdated: new Date().toLocaleString("ar-EG") }, next, { changedIds: [updatedRec.id] }) : false;
    if (!savedMeta) { showToast("فشل حفظ التعديل.", "bad"); return; }
    setRecords(next);
    setMeta(savedMeta);
    pushLog("تعديل سجل", `اللوحة ${updatedRec.plate_raw}`, 1);
    showToast("تم حفظ التعديل");
    setEditing(null);
  };

  if (list.length === 0) {
    return <EmptyState icon={Database} title="القاعدة فارغة" text="ابدأ برفع ملف أساسي لتظهر السجلات هنا." />;
  }

  return (
    <div>
      <SectionTitle title="استعراض وبحث وتصفية قاعدة البيانات" />

      <div style={{
        background: COLORS.panel, border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: 14,
        display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14, alignItems: "flex-end",
      }}>
        <FieldWrap label="بحث باللوحة">
          <div style={{ position: "relative" }}>
            <Search size={14} style={{ position: "absolute", insetInlineStart: 10, top: 10, color: COLORS.inkMuted }} />
            <input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder="اكتب رقم اللوحة"
              style={{ ...inputStyle(), paddingInlineStart: 30, width: 160 }} />
          </div>
        </FieldWrap>
        <FieldWrap label="الشارع/الموقع">
          <select value={street} onChange={(e) => { setStreet(e.target.value); setPage(1); }} style={inputStyle()}>
            <option value="">الكل</option>
            {streets.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </FieldWrap>
        <FieldWrap label="نوع المركبة">
          <select value={type} onChange={(e) => { setType(e.target.value); setPage(1); }} style={inputStyle()}>
            <option value="">الكل</option>
            {types.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </FieldWrap>
        <FieldWrap label="من تاريخ">
          <input type="date" value={dateFrom} onChange={(e) => { setDateFrom(e.target.value); setPage(1); }} style={inputStyle()} />
        </FieldWrap>
        <FieldWrap label="إلى تاريخ">
          <input type="date" value={dateTo} onChange={(e) => { setDateTo(e.target.value); setPage(1); }} style={inputStyle()} />
        </FieldWrap>
        <button style={ghostBtn()} onClick={() => { setQ(""); setStreet(""); setType(""); setDateFrom(""); setDateTo(""); setPage(1); }}>
          مسح الفلاتر
        </button>
        <button style={primaryBtn(false)} onClick={() => exportRecordsToExcel(filtered, `نتائج_البحث_${todayISO()}.xlsx`)}>
          <FileDown size={15} /> تصدير النتائج ({filtered.length.toLocaleString("ar-EG")})
        </button>
      </div>

      <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.line}`, borderRadius: 10, overflow: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13, minWidth: 680 }}>
          <thead>
            <tr style={{ background: "#F5F7FA", textAlign: "right" }}>
              {["اللوحة", "الشارع/الموقع", "النوع الأساسي", "آخر رصد", "عدد مرات الرصد", ""].map((h) => (
                <th key={h} style={{ padding: "10px 12px", fontWeight: 700, borderBottom: `1px solid ${COLORS.line}` }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.map((r) => (
              <tr key={r.id} style={{ borderBottom: `1px solid ${COLORS.line}` }}>
                <td style={{ padding: "9px 12px" }}>
                  <span style={{
                    background: COLORS.goldSoft, border: `1px solid ${COLORS.gold}`, borderRadius: 5,
                    padding: "3px 8px", fontFamily: FONT_HEAD, fontWeight: 700, fontSize: 12.5,
                  }}>{r.plate_raw}</span>
                </td>
                <td style={{ padding: "9px 12px" }}><LocationCell value={r.street} /></td>
                <td style={{ padding: "9px 12px" }}>{r.car_type || "—"}</td>
                <td style={{ padding: "9px 12px" }}>{r.last_date}</td>
                <td style={{ padding: "9px 12px" }}>{r.observations.length}</td>
                <td style={{ padding: "9px 12px", display: "flex", gap: 8 }}>
                  <button onClick={() => setEditing(r)} title="تعديل" style={iconBtn()}><Pencil size={14} /></button>
                  <button onClick={() => deleteRecord(r.id)} title="حذف" style={iconBtn(COLORS.bad)}><Trash2 size={14} /></button>
                </td>
              </tr>
            ))}
            {pageRows.length === 0 && (
              <tr><td colSpan={6} style={{ padding: 24, textAlign: "center", color: COLORS.inkMuted }}>لا توجد نتائج مطابقة للفلاتر الحالية.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 12, fontSize: 13 }}>
        <span style={{ color: COLORS.inkMuted }}>صفحة {page} من {totalPages} — {filtered.length.toLocaleString("ar-EG")} سجل</span>
        <div style={{ display: "flex", gap: 6 }}>
          <button style={ghostBtn()} disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronRight size={14} /></button>
          <button style={ghostBtn()} disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronLeft size={14} /></button>
        </div>
      </div>

      {editing && <EditModal record={editing} onClose={() => setEditing(null)} onSave={saveEdit} />}
    </div>
  );
}

function FieldWrap({ label, children }) {
  return (
    <div>
      <div style={{ fontSize: 11.5, color: COLORS.inkMuted, marginBottom: 4 }}>{label}</div>
      {children}
    </div>
  );
}
function inputStyle() {
  return { padding: "8px 10px", borderRadius: 6, border: `1px solid ${COLORS.line}`, fontSize: 13 };
}
function iconBtn(color) {
  return {
    background: "transparent", border: `1px solid ${COLORS.line}`, borderRadius: 6, padding: 6,
    color: color || COLORS.ink, display: "flex",
  };
}

function EditModal({ record, onClose, onSave }) {
  const [street, setStreet] = useState(record.street);
  const [carType, setCarType] = useState(record.car_type);
  const [lastDate, setLastDate] = useState(record.last_date);

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(11,23,48,.5)", display: "flex",
      alignItems: "center", justifyContent: "center", zIndex: 60, padding: 16,
    }}>
      <div style={{ background: "#fff", borderRadius: 12, padding: 22, width: 380, maxWidth: "100%" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <div style={{ fontFamily: FONT_HEAD, fontWeight: 800 }}>تعديل السجل — {record.plate_raw}</div>
          <button onClick={onClose} style={{ background: "none", border: "none" }}><X size={18} /></button>
        </div>
        <FieldWrap label="الشارع/الموقع">
          <input value={street} onChange={(e) => setStreet(e.target.value)} style={{ ...inputStyle(), width: "100%" }} />
        </FieldWrap>
        <div style={{ height: 10 }} />
        <FieldWrap label="نوع المركبة">
          <input value={carType} onChange={(e) => setCarType(e.target.value)} style={{ ...inputStyle(), width: "100%" }} />
        </FieldWrap>
        <div style={{ height: 10 }} />
        <FieldWrap label="آخر تاريخ رصد">
          <input type="date" value={lastDate} onChange={(e) => setLastDate(e.target.value)} style={{ ...inputStyle(), width: "100%" }} />
        </FieldWrap>
        <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
          <button style={primaryBtn(false)} onClick={() => onSave({ ...record, street, car_type: carType, last_date: lastDate })}>
            <Save size={15} /> حفظ
          </button>
          <button style={ghostBtn()} onClick={onClose}>إلغاء</button>
        </div>
      </div>
    </div>
  );
}

/* ============================== الأمان والنسخ الاحتياطي ============================== */
function SecurityCenter({ records, meta, logs, setRecords, setMeta, pushLog, showToast }) {
  const [confirmText, setConfirmText] = useState("");
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const restoreRef = useRef(null);

  const backupAll = () => {
    const payload = { meta, records, exportedAt: new Date().toISOString() };
    downloadBlob(JSON.stringify(payload, null, 2), `نسخة_احتياطية_${todayISO()}.json`, "application/json");
    pushLog("تنزيل نسخة احتياطية", `${Object.keys(records).length} سجل`, Object.keys(records).length);
    showToast("تم تنزيل النسخة الاحتياطية");
  };

  const restoreFromFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const payload = JSON.parse(e.target.result);
        if (!payload.records) throw new Error("bad");
        const restoredMeta = { ...(payload.meta || {}), baseFileName: payload.meta?.baseFileName || file.name, lastUpdated: new Date().toLocaleString("ar-EG"), activeGeneration: makeGeneration() };
        persistDB(restoredMeta, payload.records, { replace: true }).then((ok) => {
          if (!ok) { showToast("فشل حفظ النسخة المستعادة.", "bad"); return; }
          setRecords(payload.records);
          setMeta(restoredMeta);
          pushLog("استعادة نسخة احتياطية", file.name, Object.keys(payload.records).length);
          showToast("تمت استعادة النسخة الاحتياطية وحفظها");
        });
      } catch {
        showToast("ملف النسخة الاحتياطية غير صالح", "bad");
      }
    };
    reader.readAsText(file);
  };

  const resetAll = () => {
    const emptyMeta = { baseFileName: null, lastUpdated: null };
    persistDB(emptyMeta, {}, { replace: true }).then((ok) => {
      if (!ok) { showToast("فشل مسح القاعدة من التخزين.", "bad"); return; }
      setRecords({});
      setMeta(emptyMeta);
    });
    pushLog("إعادة ضبط المصنع", "تم مسح كامل البيانات", 0);
    showToast("تم مسح جميع البيانات", "bad");
    setShowResetConfirm(false);
    setConfirmText("");
  };

  return (
    <div>
      <SectionTitle title="مركز الأمان والنسخ الاحتياطي وسجل العمليات" />

      <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 20 }}>
        <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: 18, flex: "1 1 260px" }}>
          <div style={{ fontWeight: 700, marginBottom: 8, display: "flex", alignItems: "center", gap: 8 }}>
            <FileDown size={16} color={COLORS.navy} /> نسخة احتياطية كاملة
          </div>
          <div style={{ fontSize: 12.5, color: COLORS.inkMuted, marginBottom: 12 }}>
            تنزيل كل السجلات ({Object.keys(records).length.toLocaleString("ar-EG")}) بصيغة JSON لحفظها أو نقلها.
          </div>
          <button style={primaryBtn(false)} onClick={backupAll}><FileDown size={15} /> تنزيل نسخة احتياطية</button>
        </div>

        <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: 18, flex: "1 1 260px" }}>
          <div style={{ fontWeight: 700, marginBottom: 8, display: "flex", alignItems: "center", gap: 8 }}>
            <FolderOpen size={16} color={COLORS.navy} /> استعادة نسخة سابقة
          </div>
          <div style={{ fontSize: 12.5, color: COLORS.inkMuted, marginBottom: 12 }}>
            استعادة قاعدة البيانات بالكامل من ملف نسخة احتياطية JSON. سيستبدل هذا البيانات الحالية.
          </div>
          <button style={ghostBtn()} onClick={() => restoreRef.current?.click()}><FolderOpen size={15} /> اختيار ملف الاستعادة</button>
          <input ref={restoreRef} type="file" accept=".json" hidden onChange={(e) => restoreFromFile(e.target.files[0])} />
        </div>

        <div style={{ background: "#FFF3F1", border: `1px solid ${COLORS.bad}`, borderRadius: 10, padding: 18, flex: "1 1 260px" }}>
          <div style={{ fontWeight: 700, marginBottom: 8, display: "flex", alignItems: "center", gap: 8, color: COLORS.bad }}>
            <RotateCcw size={16} /> إعادة ضبط المصنع
          </div>
          <div style={{ fontSize: 12.5, color: "#8A3A32", marginBottom: 12 }}>
            مسح كامل البيانات نهائياً. هذا الإجراء لا يمكن التراجع عنه.
          </div>
          <button style={dangerBtn()} onClick={() => setShowResetConfirm(true)}><Trash2 size={15} /> مسح جميع البيانات</button>
        </div>
      </div>

      <SectionTitle title="سجل الأنشطة الكامل" small />
      <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.line}`, borderRadius: 10, maxHeight: 320, overflow: "auto" }}>
        {logs.length === 0 ? (
          <div style={{ padding: 16, color: COLORS.inkMuted, fontSize: 13 }}>لا توجد أنشطة مسجّلة بعد.</div>
        ) : logs.map((l, i) => (
          <div key={i} style={{
            padding: "10px 16px", fontSize: 13, borderBottom: i < logs.length - 1 ? `1px solid ${COLORS.line}` : "none",
            display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap",
          }}>
            <span><b>{l.action}</b> — {l.details} <span style={{ color: COLORS.inkMuted }}>({l.count} سجل متأثر)</span></span>
            <span style={{ color: COLORS.inkMuted, fontSize: 12 }}>{l.time}</span>
          </div>
        ))}
      </div>

      {showResetConfirm && (
        <div style={{
          position: "fixed", inset: 0, background: "rgba(11,23,48,.5)", display: "flex",
          alignItems: "center", justifyContent: "center", zIndex: 60, padding: 16,
        }}>
          <div style={{ background: "#fff", borderRadius: 12, padding: 22, width: 400, maxWidth: "100%" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, color: COLORS.bad, marginBottom: 10 }}>
              <TriangleAlert size={20} />
              <div style={{ fontFamily: FONT_HEAD, fontWeight: 800 }}>تأكيد إعادة الضبط</div>
            </div>
            <div style={{ fontSize: 13, color: COLORS.inkMuted, marginBottom: 12, lineHeight: 1.7 }}>
              سيتم حذف {Object.keys(records).length.toLocaleString("ar-EG")} سجل نهائياً. اكتب كلمة <b>حذف</b> للتأكيد.
            </div>
            <input value={confirmText} onChange={(e) => setConfirmText(e.target.value)} style={{ ...inputStyle(), width: "100%" }} />
            <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
              <button style={dangerBtn()} disabled={confirmText !== "حذف"} onClick={resetAll}
                onMouseDown={(e) => confirmText !== "حذف" && e.preventDefault()}>
                <Trash2 size={15} /> تأكيد الحذف النهائي
              </button>
              <button style={ghostBtn()} onClick={() => { setShowResetConfirm(false); setConfirmText(""); }}>تراجع</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
